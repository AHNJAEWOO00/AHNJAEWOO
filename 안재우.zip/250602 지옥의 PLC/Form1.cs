﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;




namespace _250602_지옥의_PLC
{
    public partial class Form1 : Form
    {


        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        private string ReadDataRackConv = "00000000";  // Readdata[19] ← 랙
        private string WriteDataRackConv = "00000000"; // Writedata[1] ← 랙



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            lbl_status.Text = "수동 운전"; // 초기 버튼 텍스트 설정
            btn_stopnclear_Click(null, null);//정지 초기화
            if (connect != 0)
            {
                btn_status.Text = "OK";
                btn_status.ForeColor = Color.Blue;
                btn_status.BackColor = Color.Pink;
                timer1.Interval = 100;
                timer1.Start();
            }
            else
            {
                btn_status.Text = "NG";
                btn_status.ForeColor = Color.Black;
                btn_status.BackColor = Color.White;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btn_stopnclear_Click(object sender, EventArgs e)
        {
            Writedata[0] = (byte)0x0a;
            CIFX.xChannelWrite(Writedata);
            Mode = 0;
            AutoRun = 0;
            Count = 0;
            ClickCount = 0;
            lbl_status.Text = "정지(초기화)";
        }
        
        
        
        
        int AutoRun = 0;//switch case 구동 횟수 카운트 변수 선언
        int Count = 0;//자동운전 횟수 지정 변수 선언
        bool AutoRunStop = false;//모터 정지 여부 변수 선언
        int Mode = 0;//자동운전 모드 구분 변수 선언





        private void btn_auto_count_Click(object sender, EventArgs e)
        {
            timer2.Interval = 1000;
            timer2.Start();
            Mode = 1;// 모드 1 자동운전
            AutoRun = 0; //초기값
            Count = 0;// 초기값
            lbl_status.Text = "자동운전(횟수지정)";
        }

        private int ClickCount = 0;//step 버튼 클릭 횟수 카운트
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (btn_status.Text == "OK")
            {
                Readdata = CIFX.xChannelRead();
                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                lbl_input.Text = ReadDataConv;
                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                lbl_output.Text = WritedataConv;
                ReadDataRackConv = Convert.ToString(Readdata[19], 2).PadLeft(8, '0');
                lbl_input2.Text = ReadDataRackConv;
                WriteDataRackConv = Convert.ToString(Writedata[1], 2).PadLeft(8, '0');
                lbl_output2.Text = WriteDataRackConv;
                // 랙앤피니언 전진 센서 (bit 0)
                lbl_rnpfor.BackColor = (ReadDataRackConv[7] == '1') ? Color.GreenYellow : Color.White;

                // 랙앤피니언 후진 센서 (bit 1)
                lbl_rnpback.BackColor = (ReadDataRackConv[7] == '0') ? Color.GreenYellow : Color.White;

                lbl_mtsenser.BackColor = (ReadDataConv[1] == '1') ? Color.GreenYellow :
                Color.White;//모터센서 1

                lbl_stprsilfor.BackColor = (ReadDataConv[6] == '1') ? Color.GreenYellow :
                Color.White;//스토퍼전진 7

                lbl_stprsilback.BackColor = (ReadDataConv[7] == '1') ? Color.GreenYellow :
                Color.White;//스토퍼후진 6

                lbl_silfor.BackColor = (ReadDataConv[4] == '1') ? Color.GreenYellow :
                Color.White;//전후진전진 5

                lbl_silback.BackColor = (ReadDataConv[5] == '1') ? Color.GreenYellow :
                Color.White;//전후진후진 4
                
                lbl_updwnsilfor.BackColor = (ReadDataConv[2] == '1') ? Color.GreenYellow :
                Color.White;//상하강전진 3

                lbl_updwnsilback.BackColor = (ReadDataConv[3] == '1') ? Color.GreenYellow :
                Color.White;//상하강후진 2

            }
        }

        private void rbtn_motorcw_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x40;
            Writedata[0] &= unchecked((byte)~0x80);
            CIFX.xChannelWrite(Writedata);
            lbl_status.Text = "수동운전 상태";
        }

        private void rbtn_motorccw_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x80;
            Writedata[0] &= unchecked((byte)~0x40);
            CIFX.xChannelWrite(Writedata);
            lbl_status.Text = "수동운전 상태";
        }

        private void rbtn_stpsilfor_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[7] == '1')
            {
                Writedata[0] |= 0x01;
                Writedata[0] &= unchecked((byte)~0x02);
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void rbtn_stpsilback_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[6] == '1')
            {
                Writedata[0] |= 0x02;
                Writedata[0] &= unchecked((byte)~0x01);
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void rbtn_silfor_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[5] == '1')
            {
                Writedata[0] |= 0x04;
                Writedata[0] &= unchecked((byte)~0x08);
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void rbtn_silback_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[4] == '1')
            {
                Writedata[0] |= 0x08;
                Writedata[0] &= unchecked((byte)~0x04);
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void rbtn_updwnsilfor_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[3] == '1')
            {
                Writedata[0] ^= 0x10;
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void rbtn_updwnsilback_CheckedChanged(object sender, EventArgs e)
        {
            if (ReadDataConv[2] == '1')
            {
                Writedata[0] ^= 0x10;
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "수동운전 상태";
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            lbl_worktimes.Text = Count.ToString();
            int Counting = Convert.ToInt32(numericUpDown1.Value);
            lbl_step.Text = (Mode == 2) ? AutoRun.ToString() : "not step driving";



            if ((Mode == 1 && Count < Counting) || (Mode == 2 && AutoRunStop == true))
            {
                switch (AutoRun)
                {
                    case 0: // 모터 40 정회전 2초 구동 후 스토퍼 실린더 전진 01
                        Writedata[0] |= 0x40;
                        CIFX.xChannelWrite(Writedata);
                        Thread.Sleep(2000);
                        Writedata[0] &= unchecked((byte)~0x40);
                        CIFX.xChannelWrite(Writedata);
                        if (ReadDataConv[7] == '1')
                        {
                            Writedata[0] |= 0x01;
                            Writedata[0] &= unchecked((byte)~0x02);
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        break;
                    case 1: // 스토퍼 실린더 후진 02, 전후진 실린더 전진 04
                        if (ReadDataConv[6] == '1' && ReadDataConv[5] == '1')
                        {
                            Writedata[0] = 0x06;
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        break;
                    case 2: // 상하강 실린더 전진 10, 1초 후 상하강 실린더 후진
                        if (ReadDataConv[4] == '1' && ReadDataConv[3] == '1')
                        {
                            Writedata[0] |= 0x10;
                            CIFX.xChannelWrite(Writedata);
                        }
                        Thread.Sleep(1000);
                        if (ReadDataConv[2] == '1')
                        {
                            Writedata[0] &= unchecked((byte)~0x10);
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        break;
                    case 3: // 전후진 실린더 후진
                        if (ReadDataConv[4] == '1')
                        {
                            Thread.Sleep(1000);
                            Writedata[0] = 0x08;
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        break;
                    case 4: // 모터 역회전 2초 구동
                        if (ReadDataConv[5] == '1')
                        {
                            Writedata[0] |= 0x80;
                            CIFX.xChannelWrite(Writedata);
                            Thread.Sleep(2000);
                            Writedata[0] &= unchecked((byte)~0x80);
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        break;
                    case 5: // 상하강 실린더 전진 0.5초 후 후진
                        if (ReadDataConv[3] == '1')
                        {
                            Writedata[0] |= 0x10;
                            CIFX.xChannelWrite(Writedata);
                        }
                        Thread.Sleep(500);
                        if (ReadDataConv[2] == '1')
                        {
                            Writedata[0] &= unchecked((byte)~0x10);
                            CIFX.xChannelWrite(Writedata);
                            if (Mode == 1) AutoRun++;
                            AutoRunStop = false;
                        }
                        ClickCount = 0;
                        break;
                    case 6: // 종료
                        if (Mode == 1)
                        {
                            AutoRun = 0;
                            Count++;
                        }
                        break;

                }
            }
        }

        private void btn_manual_control_Click(object sender, EventArgs e)
        {
            timer2.Interval = 100;
            timer2.Start();
            Mode = 2;// 모드 2 수동스텝 운전
            AutoRunStop = true;// 수동 스텝 버튼을 클릭하면 AutoRunStop변수에 true flag

            AutoRun = ClickCount; // AutoRun 값을 클릭 횟수로 설정
            ClickCount++; // 클릭 횟수 증가
            Count = 0;
            lbl_status.Text = "수동 스텝 제어";
        }
        int seqStep = 0;
        bool isSeqRunning = false;
        private void button2_Click(object sender, EventArgs e)
        {
            seqStep = 0;
            isSeqRunning = true;
            timer3.Interval = 100;
            timer3.Start();
            lbl_status.Text = "자동 순차 동작 시작";
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (!isSeqRunning) return;

            Readdata = CIFX.xChannelRead();
            ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');

            switch (seqStep)
            {
                case 0: // 상하강 실린더 전진
                    lbl_step.Text = "1";
                    Writedata[0] |= 0x10;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(1000); // 1초 유지
                    Writedata[0] &= unchecked((byte)~0x10);
                    CIFX.xChannelWrite(Writedata);
                    seqStep++;
                    break;

                case 1: // DC 모터 역회전 3초
                    lbl_step.Text = "2";
                    Writedata[0] |= 0x80;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(3000);
                    Writedata[0] &= unchecked((byte)~0x80);
                    CIFX.xChannelWrite(Writedata);
                    seqStep++;
                    break;

                case 2: // 전후진 실린더 전진
                    lbl_step.Text = "3";
                    Writedata[0] |= 0x04;
                    Writedata[0] &= unchecked((byte)~0x08);
                    CIFX.xChannelWrite(Writedata);
                    seqStep++;
                    break;

                case 3: // 상하강 전진 → 완료되면 후진
                    lbl_step.Text = "4";
                    Writedata[0] |= 0x10; // 상하강 전진
                    CIFX.xChannelWrite(Writedata);

                    if (ReadDataConv[2] == '1') // 전진 완료 감지 (센서 3번이 1이 되면)
                    {
                        Thread.Sleep(500); // 안정 시간
                        Writedata[0] &= unchecked((byte)~0x10); // 상하강 후진
                        CIFX.xChannelWrite(Writedata);
                        seqStep++;
                    }
                    break;

                case 4: // 전후진 실린더 후진
                    lbl_step.Text = "5";
                    Writedata[0] |= 0x08;
                    Writedata[0] &= unchecked((byte)~0x04);
                    CIFX.xChannelWrite(Writedata);
                    seqStep++;
                    break;

                case 5: // DC 모터 정회전 3초
                    lbl_step.Text = "6";
                    Writedata[0] |= 0x40;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(3000);
                    Writedata[0] &= unchecked((byte)~0x40);
                    CIFX.xChannelWrite(Writedata);
                    seqStep++;
                    break;

                case 6: // 스토퍼 실린더 전진 → 완료 후 후진
                    lbl_step.Text = "7";
                    if (ReadDataConv[7] == '1') // 스토퍼 전진 완료 감지
                    {
                        Writedata[0] |= 0x01;
                        Writedata[0] &= unchecked((byte)~0x02);
                        CIFX.xChannelWrite(Writedata);
                        Thread.Sleep(500);
                        Writedata[0] |= 0x02;
                        Writedata[0] &= unchecked((byte)~0x01);
                        CIFX.xChannelWrite(Writedata);
                        seqStep++;
                    }
                    break;

                case 7:
                    lbl_step.Text = "완료";
                    isSeqRunning = false;
                    timer3.Stop();
                    lbl_status.Text = "자동 순차 동작 완료";
                    break;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] &= unchecked((byte)~0xC0); // 0xC0 = 0x40 | 0x80
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (btn_rnpfor.Checked) // 라디오 버튼이 체크된 경우에만 실행
            {
                // 전진 명령 출력
                Writedata[1] = 0x01;
                CIFX.xChannelWrite(Writedata);
                lbl_status.Text = "랙앤피니언 전진 명령 전송";

                // 센서 입력 대기 (이벤트 기반이 아니라면 타이머에서 주기 확인)
                Task.Run(() =>
                {
                    bool forwardDone = false;
                    for (int i = 0; i < 20; i++) // 2초까지 대기 (100ms 간격)
                    {
                        Thread.Sleep(100);
                        byte[] read = CIFX.xChannelRead();
                        if ((read[19] & 0x01) != 0)
                        {
                            forwardDone = true;
                            break;
                        }
                    }

                    if (forwardDone)
                    {
                        Writedata[1] = 0x00; // 정지
                        CIFX.xChannelWrite(Writedata);
                        Invoke(new Action(() =>
                        {
                            lbl_status.Text = "랙앤피니언 전진 완료";
                        }));
                    }
                    else
                    {
                        Invoke(new Action(() =>
                        {
                            lbl_status.Text = "전진 실패 또는 타임아웃";
                        }));
                    }
                });
            }
        }
        int rapStep = 0;
        bool isRapRunning = false;
        private void btn_rapback_CheckedChanged(object sender, EventArgs e)
        {
            // 후진 명령 출력 (0x02)
            Writedata[1] = 0x02;
            CIFX.xChannelWrite(Writedata);
            lbl_status.Text = "랙앤피니언 후진 명령 전송";

            // 비동기 센서 확인
            Task.Run(() =>
            {
                bool backwardDone = false;
                for (int i = 0; i < 20; i++) // 최대 2초 대기
                {
                    Thread.Sleep(100);
                    byte[] read = CIFX.xChannelRead();
                    if ((read[19] & 0x02) != 0) // 후진 완료 감지
                    {
                        backwardDone = true;
                        break;
                    }
                }

                if (backwardDone)
                {
                    Writedata[1] = 0x00; // 정지
                    CIFX.xChannelWrite(Writedata);
                    Invoke(new Action(() =>
                    {
                        lbl_status.Text = "랙앤피니언 후진 완료";
                    }));
                }
                else
                {
                    Invoke(new Action(() =>
                    {
                        lbl_status.Text = "후진 실패 또는 타임아웃";
                    }));
                }
            });
        }

        private void btn_rapauto_Click(object sender, EventArgs e)
        {
            rapStep = 0;
            isRapRunning = true;
            timer4.Interval = 100;
            timer4.Start();
            lbl_status.Text = "자동 랙앤피니언 시퀀스 시작";
        }
        int rackBackRetry = 0;
        private void timer4_Tick(object sender, EventArgs e)
        {
            if (!isRapRunning) return;

            Readdata = CIFX.xChannelRead();
            ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
            byte r19 = Readdata[19];

            switch (rapStep)
            {
                case 0: // A 실린더 전진
                    lbl_step.Text = "1";
                    Writedata[0] |= 0x01; // A 전진
                    Writedata[0] &= unchecked((byte)~0x02);
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(2000); // 2초 지연
                    rapStep++;
                    break;

                case 1: // A 실린더 후진
                    Writedata[0] |= 0x02; // A 후진
                    Writedata[0] &= unchecked((byte)~0x01);
                    CIFX.xChannelWrite(Writedata);
                    rapStep++;
                    break;

                case 2: // DC 모터 정회전
                    lbl_step.Text = "2";
                    Writedata[0] |= 0x40;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(2000);
                    Writedata[0] &= unchecked((byte)~0x40);
                    CIFX.xChannelWrite(Writedata);
                    rapStep++;
                    break;

                case 3: // B 실린더 전진 후 후진
                    lbl_step.Text = "3";
                    Writedata[0] |= 0x04; // B 전진
                    Writedata[0] &= unchecked((byte)~0x08);
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(500);
                    Writedata[0] |= 0x08; // B 후진
                    Writedata[0] &= unchecked((byte)~0x04);
                    CIFX.xChannelWrite(Writedata);
                    rapStep++;
                    break;

                case 4: // 랙 전진
                    lbl_step.Text = "4 - 랙 전진";
                    Writedata[1] = 0x01;
                    CIFX.xChannelWrite(Writedata);

                    if ((Readdata[19] & 0x01) != 0) // 전진 완료 감지
                    {
                        Writedata[1] = 0x00;
                        CIFX.xChannelWrite(Writedata);
                        rapStep++;
                    }
                    break;

                case 5:
                    lbl_step.Text = "5 - 랙 후진";

                    if (rackBackRetry == 0)
                    {
                        Writedata[1] = 0x02;
                        CIFX.xChannelWrite(Writedata);
                    }

                    Thread.Sleep(100); // 100ms 대기
                    Readdata = CIFX.xChannelRead();

                    if ((Readdata[19] & 0x02) != 0)
                    {
                        Writedata[1] = 0x00; // 정지
                        CIFX.xChannelWrite(Writedata);
                        rackBackRetry = 0;
                        rapStep++; // ✅ 다음 스텝으로 이동
                    }
                    else
                    {
                        rackBackRetry++;
                        if (rackBackRetry > 20) // 최대 2초 대기
                        {
                            lbl_status.Text = "랙 후진 타임아웃";
                            Writedata[1] = 0x00;
                            CIFX.xChannelWrite(Writedata);
                            rackBackRetry = 0;
                            rapStep++; // 강제 진행
                        }
                    }
                    break;
                case 6: // DC 모터 역회전
                    lbl_step.Text = "6 - 모터 역회전";
                    Writedata[0] |= 0x80;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(2000);
                    Writedata[0] &= unchecked((byte)~0x80);
                    CIFX.xChannelWrite(Writedata);
                    rapStep++;
                    break;

                case 7: // C 실린더 전진 후 후진
                    lbl_step.Text = "6 - C 실린더";
                    Writedata[0] |= 0x10;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(500);
                    Writedata[0] &= unchecked((byte)~0x10);
                    CIFX.xChannelWrite(Writedata);
                    rapStep++;
                    break;

                case 8:
                    lbl_step.Text = "7 - 완료";
                    isRapRunning = false;
                    timer4.Stop();
                    lbl_status.Text = "자동 시퀀스 완료";
                    break;
            }
        }
        int rapBonusStep = 0;
        bool isRapBonusRunning = false;
        int rapBonusCount = 0;
        int rapBonusTargetCount = 0;
        private void btn_rapbonus_Click(object sender, EventArgs e)
        {
            rapBonusStep = 0;
            isRapBonusRunning = true;
            rapBonusCount = 0;
            rapBonusTargetCount = Convert.ToInt32(numericUpDown1.Value); // 반복 횟수
            timer5.Interval = 100;
            timer5.Start();
            lbl_status.Text = "보너스 자동 시퀀스 시작";
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (!isRapBonusRunning || rapBonusCount >= rapBonusTargetCount)
            {
                isRapBonusRunning = false;
                timer5.Stop();
                lbl_status.Text = "보너스 자동 시퀀스 완료";
                return;
            }

            Readdata = CIFX.xChannelRead();

            switch (rapBonusStep)
            {
                case 0: // A 실린더 전진
                    lbl_step.Text = "0 - A 전진";
                    Writedata[0] |= 0x01;
                    Writedata[0] &= unchecked((byte)~0x02);
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(500);
                    rapBonusStep++;
                    break;

                case 1: // DC 모터 정회전 2초 후 정지
                    lbl_step.Text = "1 - 모터 정회전";
                    Writedata[0] |= 0x40;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(2000);
                    Writedata[0] &= unchecked((byte)~0x40);
                    CIFX.xChannelWrite(Writedata);
                    rapBonusStep++;
                    break;

                case 2: // A 후진
                    lbl_step.Text = "2 - A 후진";
                    Writedata[0] |= 0x02;
                    Writedata[0] &= unchecked((byte)~0x01);
                    CIFX.xChannelWrite(Writedata);
                    rapBonusStep++;
                    break;

                case 3: // B, C 전진
                    lbl_step.Text = "3 - B, C 전진";
                    Writedata[0] |= 0x04 | 0x10;
                    Writedata[0] &= unchecked((byte)~0x08);
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(500);
                    rapBonusStep++;
                    break;

                case 4: // B 후진
                    lbl_step.Text = "4 - B 후진";
                    Writedata[0] |= 0x08;
                    Writedata[0] &= unchecked((byte)~0x04);
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(500);
                    rapBonusStep++;
                    break;

                case 5:
                    lbl_step.Text = "5 - 랙 전진 대기";

                    // 전진 명령
                    Writedata[1] = 0x01;
                    CIFX.xChannelWrite(Writedata);

                    // 전진 완료될 때까지 최대 2초 대기
                    for (int i = 0; i < 20; i++)
                    {
                        Thread.Sleep(100);
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[19] & 0x01) != 0) // 랙 전진 완료
                        {
                            break;
                        }
                    }

                    Writedata[1] = 0x00;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(200); // 안정화 시간

                    lbl_step.Text = "5 - 랙 후진 대기";

                    // 후진 명령
                    Writedata[1] = 0x02;
                    CIFX.xChannelWrite(Writedata);

                    for (int i = 0; i < 20; i++)
                    {
                        Thread.Sleep(100);
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[19] & 0x02) != 0) // 랙 후진 완료
                        {
                            break;
                        }
                    }

                    Writedata[1] = 0x00;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(200); // 안정화 시간

                    rapBonusStep++;
                    break;

                case 6: // 모터 역회전 2초 후 정지
                    lbl_step.Text = "6 - 모터 역회전";
                    Writedata[0] |= 0x80;
                    CIFX.xChannelWrite(Writedata);
                    Thread.Sleep(2000);
                    Writedata[0] &= unchecked((byte)~0x80);
                    CIFX.xChannelWrite(Writedata);
                    rapBonusStep++;
                    break;

                case 7: // C 후진
                    lbl_step.Text = "7 - C 후진";
                    Writedata[0] &= unchecked((byte)~0x10);
                    CIFX.xChannelWrite(Writedata);
                    rapBonusStep++;
                    break;

                case 8: // 완료
                    lbl_step.Text = "8 - 완료";
                    rapBonusCount++;
                    rapBonusStep = 0; // 반복
                    break;
            }
        }
    }
}