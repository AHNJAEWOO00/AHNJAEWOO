﻿namespace _250602_지옥의_PLC
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_status = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_input = new System.Windows.Forms.Label();
            this.lbl_output = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_status = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_worktimes = new System.Windows.Forms.Label();
            this.lbl_step = new System.Windows.Forms.Label();
            this.btn_auto_count = new System.Windows.Forms.Button();
            this.btn_manual_control = new System.Windows.Forms.Button();
            this.btn_stopnclear = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_mtsenser = new System.Windows.Forms.Label();
            this.lbl_stprsilfor = new System.Windows.Forms.Label();
            this.lbl_stprsilback = new System.Windows.Forms.Label();
            this.lbl_silfor = new System.Windows.Forms.Label();
            this.lbl_silback = new System.Windows.Forms.Label();
            this.lbl_updwnsilfor = new System.Windows.Forms.Label();
            this.lbl_updwnsilback = new System.Windows.Forms.Label();
            this.rbtn_motorcw = new System.Windows.Forms.RadioButton();
            this.rbtn_motorccw = new System.Windows.Forms.RadioButton();
            this.rbtn_stpsilfor = new System.Windows.Forms.RadioButton();
            this.rbtn_stpsilback = new System.Windows.Forms.RadioButton();
            this.rbtn_silfor = new System.Windows.Forms.RadioButton();
            this.rbtn_silback = new System.Windows.Forms.RadioButton();
            this.rbtn_updwnsilfor = new System.Windows.Forms.RadioButton();
            this.rbtn_updwnsilback = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.btn_autopart2 = new System.Windows.Forms.Button();
            this.btn_motorstop = new System.Windows.Forms.RadioButton();
            this.btn_rnpfor = new System.Windows.Forms.RadioButton();
            this.btn_rapback = new System.Windows.Forms.RadioButton();
            this.lbl_rnpfor = new System.Windows.Forms.Label();
            this.lbl_rnpback = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_input2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_output2 = new System.Windows.Forms.Label();
            this.btn_rapauto = new System.Windows.Forms.Button();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.btn_rapbonus = new System.Windows.Forms.Button();
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(638, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "컨베이어 공작물 이송 시스템";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "EtherCAT Master Status";
            // 
            // btn_status
            // 
            this.btn_status.Location = new System.Drawing.Point(393, 146);
            this.btn_status.Name = "btn_status";
            this.btn_status.Size = new System.Drawing.Size(219, 43);
            this.btn_status.TabIndex = 2;
            this.btn_status.Text = "통신 연결 상태";
            this.btn_status.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(689, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "[18]입력 :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(993, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "[0] 출력 :";
            // 
            // lbl_input
            // 
            this.lbl_input.AutoSize = true;
            this.lbl_input.Location = new System.Drawing.Point(831, 155);
            this.lbl_input.Name = "lbl_input";
            this.lbl_input.Size = new System.Drawing.Size(90, 24);
            this.lbl_input.TabIndex = 5;
            this.lbl_input.Text = "address";
            // 
            // lbl_output
            // 
            this.lbl_output.AutoSize = true;
            this.lbl_output.Location = new System.Drawing.Point(1118, 155);
            this.lbl_output.Name = "lbl_output";
            this.lbl_output.Size = new System.Drawing.Size(90, 24);
            this.lbl_output.TabIndex = 6;
            this.lbl_output.Text = "address";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.lbl_rnpback);
            this.groupBox1.Controls.Add(this.lbl_rnpfor);
            this.groupBox1.Controls.Add(this.lbl_updwnsilback);
            this.groupBox1.Controls.Add(this.lbl_updwnsilfor);
            this.groupBox1.Controls.Add(this.lbl_silback);
            this.groupBox1.Controls.Add(this.lbl_silfor);
            this.groupBox1.Controls.Add(this.lbl_stprsilback);
            this.groupBox1.Controls.Add(this.lbl_stprsilfor);
            this.groupBox1.Controls.Add(this.lbl_mtsenser);
            this.groupBox1.Location = new System.Drawing.Point(81, 228);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1177, 219);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "입력확인";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1328, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "동작상태 :";
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Location = new System.Drawing.Point(1488, 77);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(58, 24);
            this.lbl_status.TabIndex = 9;
            this.lbl_status.Text = "없음";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1328, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 24);
            this.label7.TabIndex = 10;
            this.label7.Text = "동작횟수설정";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(1492, 117);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 35);
            this.numericUpDown1.TabIndex = 11;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1328, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 24);
            this.label8.TabIndex = 12;
            this.label8.Text = "동작횟수";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1328, 202);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 24);
            this.label9.TabIndex = 13;
            this.label9.Text = "STEP";
            // 
            // lbl_worktimes
            // 
            this.lbl_worktimes.AutoSize = true;
            this.lbl_worktimes.Location = new System.Drawing.Point(1492, 164);
            this.lbl_worktimes.Name = "lbl_worktimes";
            this.lbl_worktimes.Size = new System.Drawing.Size(23, 24);
            this.lbl_worktimes.TabIndex = 14;
            this.lbl_worktimes.Text = "0";
            // 
            // lbl_step
            // 
            this.lbl_step.AutoSize = true;
            this.lbl_step.Location = new System.Drawing.Point(1492, 202);
            this.lbl_step.Name = "lbl_step";
            this.lbl_step.Size = new System.Drawing.Size(23, 24);
            this.lbl_step.TabIndex = 15;
            this.lbl_step.Text = "0";
            this.lbl_step.Click += new System.EventHandler(this.label11_Click);
            // 
            // btn_auto_count
            // 
            this.btn_auto_count.Location = new System.Drawing.Point(1332, 469);
            this.btn_auto_count.Name = "btn_auto_count";
            this.btn_auto_count.Size = new System.Drawing.Size(295, 80);
            this.btn_auto_count.TabIndex = 16;
            this.btn_auto_count.Text = "자동운전(횟수지정)";
            this.btn_auto_count.UseVisualStyleBackColor = true;
            this.btn_auto_count.Click += new System.EventHandler(this.btn_auto_count_Click);
            // 
            // btn_manual_control
            // 
            this.btn_manual_control.Location = new System.Drawing.Point(1332, 559);
            this.btn_manual_control.Name = "btn_manual_control";
            this.btn_manual_control.Size = new System.Drawing.Size(295, 77);
            this.btn_manual_control.TabIndex = 17;
            this.btn_manual_control.Text = "수동 스텝 제어";
            this.btn_manual_control.UseVisualStyleBackColor = true;
            this.btn_manual_control.Click += new System.EventHandler(this.btn_manual_control_Click);
            // 
            // btn_stopnclear
            // 
            this.btn_stopnclear.Location = new System.Drawing.Point(1332, 656);
            this.btn_stopnclear.Name = "btn_stopnclear";
            this.btn_stopnclear.Size = new System.Drawing.Size(295, 75);
            this.btn_stopnclear.TabIndex = 18;
            this.btn_stopnclear.Text = "정지 초기화";
            this.btn_stopnclear.UseVisualStyleBackColor = true;
            this.btn_stopnclear.Click += new System.EventHandler(this.btn_stopnclear_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_rapback);
            this.groupBox2.Controls.Add(this.btn_rnpfor);
            this.groupBox2.Controls.Add(this.btn_motorstop);
            this.groupBox2.Controls.Add(this.rbtn_updwnsilback);
            this.groupBox2.Controls.Add(this.rbtn_updwnsilfor);
            this.groupBox2.Controls.Add(this.rbtn_silback);
            this.groupBox2.Controls.Add(this.rbtn_silfor);
            this.groupBox2.Controls.Add(this.rbtn_stpsilback);
            this.groupBox2.Controls.Add(this.rbtn_stpsilfor);
            this.groupBox2.Controls.Add(this.rbtn_motorccw);
            this.groupBox2.Controls.Add(this.rbtn_motorcw);
            this.groupBox2.Location = new System.Drawing.Point(81, 453);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1177, 275);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "수동 출력 제어";
            // 
            // lbl_mtsenser
            // 
            this.lbl_mtsenser.AutoSize = true;
            this.lbl_mtsenser.Location = new System.Drawing.Point(24, 50);
            this.lbl_mtsenser.Name = "lbl_mtsenser";
            this.lbl_mtsenser.Size = new System.Drawing.Size(170, 24);
            this.lbl_mtsenser.TabIndex = 0;
            this.lbl_mtsenser.Text = "모터 센서 감지";
            // 
            // lbl_stprsilfor
            // 
            this.lbl_stprsilfor.AutoSize = true;
            this.lbl_stprsilfor.Location = new System.Drawing.Point(254, 50);
            this.lbl_stprsilfor.Name = "lbl_stprsilfor";
            this.lbl_stprsilfor.Size = new System.Drawing.Size(218, 24);
            this.lbl_stprsilfor.TabIndex = 1;
            this.lbl_stprsilfor.Text = "스토퍼 실린더 전진";
            // 
            // lbl_stprsilback
            // 
            this.lbl_stprsilback.AutoSize = true;
            this.lbl_stprsilback.Location = new System.Drawing.Point(254, 86);
            this.lbl_stprsilback.Name = "lbl_stprsilback";
            this.lbl_stprsilback.Size = new System.Drawing.Size(218, 24);
            this.lbl_stprsilback.TabIndex = 2;
            this.lbl_stprsilback.Text = "스토퍼 실린더 후진";
            this.lbl_stprsilback.Click += new System.EventHandler(this.label12_Click);
            // 
            // lbl_silfor
            // 
            this.lbl_silfor.AutoSize = true;
            this.lbl_silfor.Location = new System.Drawing.Point(528, 49);
            this.lbl_silfor.Name = "lbl_silfor";
            this.lbl_silfor.Size = new System.Drawing.Size(226, 24);
            this.lbl_silfor.TabIndex = 3;
            this.lbl_silfor.Text = "전 후진 실린더 전진";
            // 
            // lbl_silback
            // 
            this.lbl_silback.AutoSize = true;
            this.lbl_silback.Location = new System.Drawing.Point(528, 86);
            this.lbl_silback.Name = "lbl_silback";
            this.lbl_silback.Size = new System.Drawing.Size(226, 24);
            this.lbl_silback.TabIndex = 4;
            this.lbl_silback.Text = "전 후진 실린더 후진";
            // 
            // lbl_updwnsilfor
            // 
            this.lbl_updwnsilfor.AutoSize = true;
            this.lbl_updwnsilfor.Location = new System.Drawing.Point(817, 49);
            this.lbl_updwnsilfor.Name = "lbl_updwnsilfor";
            this.lbl_updwnsilfor.Size = new System.Drawing.Size(194, 24);
            this.lbl_updwnsilfor.TabIndex = 5;
            this.lbl_updwnsilfor.Text = "상하 실린더 전진";
            // 
            // lbl_updwnsilback
            // 
            this.lbl_updwnsilback.AutoSize = true;
            this.lbl_updwnsilback.Location = new System.Drawing.Point(817, 86);
            this.lbl_updwnsilback.Name = "lbl_updwnsilback";
            this.lbl_updwnsilback.Size = new System.Drawing.Size(194, 24);
            this.lbl_updwnsilback.TabIndex = 6;
            this.lbl_updwnsilback.Text = "상하 실린더 후진";
            // 
            // rbtn_motorcw
            // 
            this.rbtn_motorcw.AutoSize = true;
            this.rbtn_motorcw.Location = new System.Drawing.Point(775, 34);
            this.rbtn_motorcw.Name = "rbtn_motorcw";
            this.rbtn_motorcw.Size = new System.Drawing.Size(169, 28);
            this.rbtn_motorcw.TabIndex = 0;
            this.rbtn_motorcw.TabStop = true;
            this.rbtn_motorcw.Text = "모터 정회전";
            this.rbtn_motorcw.UseVisualStyleBackColor = true;
            this.rbtn_motorcw.CheckedChanged += new System.EventHandler(this.rbtn_motorcw_CheckedChanged);
            // 
            // rbtn_motorccw
            // 
            this.rbtn_motorccw.AutoSize = true;
            this.rbtn_motorccw.Location = new System.Drawing.Point(775, 68);
            this.rbtn_motorccw.Name = "rbtn_motorccw";
            this.rbtn_motorccw.Size = new System.Drawing.Size(169, 28);
            this.rbtn_motorccw.TabIndex = 1;
            this.rbtn_motorccw.TabStop = true;
            this.rbtn_motorccw.Text = "모터 역회전";
            this.rbtn_motorccw.UseVisualStyleBackColor = true;
            this.rbtn_motorccw.CheckedChanged += new System.EventHandler(this.rbtn_motorccw_CheckedChanged);
            // 
            // rbtn_stpsilfor
            // 
            this.rbtn_stpsilfor.AutoSize = true;
            this.rbtn_stpsilfor.Location = new System.Drawing.Point(28, 34);
            this.rbtn_stpsilfor.Name = "rbtn_stpsilfor";
            this.rbtn_stpsilfor.Size = new System.Drawing.Size(192, 28);
            this.rbtn_stpsilfor.TabIndex = 2;
            this.rbtn_stpsilfor.TabStop = true;
            this.rbtn_stpsilfor.Text = "A 실린더 전진";
            this.rbtn_stpsilfor.UseVisualStyleBackColor = true;
            this.rbtn_stpsilfor.CheckedChanged += new System.EventHandler(this.rbtn_stpsilfor_CheckedChanged);
            // 
            // rbtn_stpsilback
            // 
            this.rbtn_stpsilback.AutoSize = true;
            this.rbtn_stpsilback.Location = new System.Drawing.Point(28, 106);
            this.rbtn_stpsilback.Name = "rbtn_stpsilback";
            this.rbtn_stpsilback.Size = new System.Drawing.Size(192, 28);
            this.rbtn_stpsilback.TabIndex = 3;
            this.rbtn_stpsilback.TabStop = true;
            this.rbtn_stpsilback.Text = "A 실린더 후진";
            this.rbtn_stpsilback.UseVisualStyleBackColor = true;
            this.rbtn_stpsilback.CheckedChanged += new System.EventHandler(this.rbtn_stpsilback_CheckedChanged);
            // 
            // rbtn_silfor
            // 
            this.rbtn_silfor.AutoSize = true;
            this.rbtn_silfor.Location = new System.Drawing.Point(236, 35);
            this.rbtn_silfor.Name = "rbtn_silfor";
            this.rbtn_silfor.Size = new System.Drawing.Size(191, 28);
            this.rbtn_silfor.TabIndex = 4;
            this.rbtn_silfor.TabStop = true;
            this.rbtn_silfor.Text = "B 실린더 전진";
            this.rbtn_silfor.UseVisualStyleBackColor = true;
            this.rbtn_silfor.CheckedChanged += new System.EventHandler(this.rbtn_silfor_CheckedChanged);
            // 
            // rbtn_silback
            // 
            this.rbtn_silback.AutoSize = true;
            this.rbtn_silback.Location = new System.Drawing.Point(236, 106);
            this.rbtn_silback.Name = "rbtn_silback";
            this.rbtn_silback.Size = new System.Drawing.Size(191, 28);
            this.rbtn_silback.TabIndex = 5;
            this.rbtn_silback.TabStop = true;
            this.rbtn_silback.Text = "B 실린더 후진";
            this.rbtn_silback.UseVisualStyleBackColor = true;
            this.rbtn_silback.CheckedChanged += new System.EventHandler(this.rbtn_silback_CheckedChanged);
            // 
            // rbtn_updwnsilfor
            // 
            this.rbtn_updwnsilfor.AutoSize = true;
            this.rbtn_updwnsilfor.Location = new System.Drawing.Point(486, 35);
            this.rbtn_updwnsilfor.Name = "rbtn_updwnsilfor";
            this.rbtn_updwnsilfor.Size = new System.Drawing.Size(192, 28);
            this.rbtn_updwnsilfor.TabIndex = 6;
            this.rbtn_updwnsilfor.TabStop = true;
            this.rbtn_updwnsilfor.Text = "C 실린더 전진";
            this.rbtn_updwnsilfor.UseVisualStyleBackColor = true;
            this.rbtn_updwnsilfor.CheckedChanged += new System.EventHandler(this.rbtn_updwnsilfor_CheckedChanged);
            // 
            // rbtn_updwnsilback
            // 
            this.rbtn_updwnsilback.AutoSize = true;
            this.rbtn_updwnsilback.Location = new System.Drawing.Point(486, 106);
            this.rbtn_updwnsilback.Name = "rbtn_updwnsilback";
            this.rbtn_updwnsilback.Size = new System.Drawing.Size(192, 28);
            this.rbtn_updwnsilback.TabIndex = 7;
            this.rbtn_updwnsilback.TabStop = true;
            this.rbtn_updwnsilback.Text = "C 실린더 후진";
            this.rbtn_updwnsilback.UseVisualStyleBackColor = true;
            this.rbtn_updwnsilback.CheckedChanged += new System.EventHandler(this.rbtn_updwnsilback_CheckedChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // btn_autopart2
            // 
            this.btn_autopart2.Location = new System.Drawing.Point(1332, 361);
            this.btn_autopart2.Name = "btn_autopart2";
            this.btn_autopart2.Size = new System.Drawing.Size(295, 86);
            this.btn_autopart2.TabIndex = 21;
            this.btn_autopart2.Text = "자동운전 PART 2";
            this.btn_autopart2.UseVisualStyleBackColor = true;
            this.btn_autopart2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_motorstop
            // 
            this.btn_motorstop.AutoSize = true;
            this.btn_motorstop.Location = new System.Drawing.Point(775, 106);
            this.btn_motorstop.Name = "btn_motorstop";
            this.btn_motorstop.Size = new System.Drawing.Size(145, 28);
            this.btn_motorstop.TabIndex = 8;
            this.btn_motorstop.TabStop = true;
            this.btn_motorstop.Text = "모터 정지";
            this.btn_motorstop.UseVisualStyleBackColor = true;
            this.btn_motorstop.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // btn_rnpfor
            // 
            this.btn_rnpfor.AutoSize = true;
            this.btn_rnpfor.Location = new System.Drawing.Point(28, 207);
            this.btn_rnpfor.Name = "btn_rnpfor";
            this.btn_rnpfor.Size = new System.Drawing.Size(260, 28);
            this.btn_rnpfor.TabIndex = 9;
            this.btn_rnpfor.TabStop = true;
            this.btn_rnpfor.Text = "Rack and pinion 전진";
            this.btn_rnpfor.UseVisualStyleBackColor = true;
            this.btn_rnpfor.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // btn_rapback
            // 
            this.btn_rapback.AutoSize = true;
            this.btn_rapback.Location = new System.Drawing.Point(312, 207);
            this.btn_rapback.Name = "btn_rapback";
            this.btn_rapback.Size = new System.Drawing.Size(260, 28);
            this.btn_rapback.TabIndex = 10;
            this.btn_rapback.TabStop = true;
            this.btn_rapback.Text = "Rack and pinion 후진";
            this.btn_rapback.UseVisualStyleBackColor = true;
            this.btn_rapback.CheckedChanged += new System.EventHandler(this.btn_rapback_CheckedChanged);
            // 
            // lbl_rnpfor
            // 
            this.lbl_rnpfor.AutoSize = true;
            this.lbl_rnpfor.Location = new System.Drawing.Point(254, 146);
            this.lbl_rnpfor.Name = "lbl_rnpfor";
            this.lbl_rnpfor.Size = new System.Drawing.Size(229, 24);
            this.lbl_rnpfor.TabIndex = 7;
            this.lbl_rnpfor.Text = "Rack and pinion 전진";
            // 
            // lbl_rnpback
            // 
            this.lbl_rnpback.AutoSize = true;
            this.lbl_rnpback.Location = new System.Drawing.Point(528, 146);
            this.lbl_rnpback.Name = "lbl_rnpback";
            this.lbl_rnpback.Size = new System.Drawing.Size(229, 24);
            this.lbl_rnpback.TabIndex = 8;
            this.lbl_rnpback.Text = "Rack and pinion 후진";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(689, 201);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 24);
            this.label11.TabIndex = 22;
            this.label11.Text = "[19]입력 :";
            // 
            // lbl_input2
            // 
            this.lbl_input2.AutoSize = true;
            this.lbl_input2.Location = new System.Drawing.Point(831, 202);
            this.lbl_input2.Name = "lbl_input2";
            this.lbl_input2.Size = new System.Drawing.Size(90, 24);
            this.lbl_input2.TabIndex = 23;
            this.lbl_input2.Text = "address";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(912, -26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 24);
            this.label13.TabIndex = 24;
            this.label13.Text = "[1] 출력 :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(993, 202);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(119, 24);
            this.label14.TabIndex = 24;
            this.label14.Text = "[1] 출력 :";
            // 
            // lbl_output2
            // 
            this.lbl_output2.AutoSize = true;
            this.lbl_output2.Location = new System.Drawing.Point(1118, 201);
            this.lbl_output2.Name = "lbl_output2";
            this.lbl_output2.Size = new System.Drawing.Size(90, 24);
            this.lbl_output2.TabIndex = 25;
            this.lbl_output2.Text = "address";
            // 
            // btn_rapauto
            // 
            this.btn_rapauto.Location = new System.Drawing.Point(1332, 251);
            this.btn_rapauto.Name = "btn_rapauto";
            this.btn_rapauto.Size = new System.Drawing.Size(150, 78);
            this.btn_rapauto.TabIndex = 26;
            this.btn_rapauto.Text = "랙앤피니언자동1번";
            this.btn_rapauto.UseVisualStyleBackColor = true;
            this.btn_rapauto.Click += new System.EventHandler(this.btn_rapauto_Click);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // btn_rapbonus
            // 
            this.btn_rapbonus.Location = new System.Drawing.Point(1496, 251);
            this.btn_rapbonus.Name = "btn_rapbonus";
            this.btn_rapbonus.Size = new System.Drawing.Size(131, 78);
            this.btn_rapbonus.TabIndex = 27;
            this.btn_rapbonus.Text = "랙앤피니언자동2번";
            this.btn_rapbonus.UseVisualStyleBackColor = true;
            this.btn_rapbonus.Click += new System.EventHandler(this.btn_rapbonus_Click);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1897, 821);
            this.Controls.Add(this.btn_rapbonus);
            this.Controls.Add(this.btn_rapauto);
            this.Controls.Add(this.lbl_output2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbl_input2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btn_autopart2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_stopnclear);
            this.Controls.Add(this.btn_manual_control);
            this.Controls.Add(this.btn_auto_count);
            this.Controls.Add(this.lbl_step);
            this.Controls.Add(this.lbl_worktimes);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbl_output);
            this.Controls.Add(this.lbl_input);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_status);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_status;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_input;
        private System.Windows.Forms.Label lbl_output;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_worktimes;
        private System.Windows.Forms.Button btn_auto_count;
        private System.Windows.Forms.Button btn_manual_control;
        private System.Windows.Forms.Button btn_stopnclear;
        private System.Windows.Forms.Label lbl_updwnsilback;
        private System.Windows.Forms.Label lbl_updwnsilfor;
        private System.Windows.Forms.Label lbl_silback;
        private System.Windows.Forms.Label lbl_silfor;
        private System.Windows.Forms.Label lbl_stprsilback;
        private System.Windows.Forms.Label lbl_stprsilfor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtn_updwnsilback;
        private System.Windows.Forms.RadioButton rbtn_updwnsilfor;
        private System.Windows.Forms.RadioButton rbtn_silback;
        private System.Windows.Forms.RadioButton rbtn_stpsilback;
        private System.Windows.Forms.RadioButton rbtn_stpsilfor;
        private System.Windows.Forms.RadioButton rbtn_motorccw;
        private System.Windows.Forms.RadioButton rbtn_motorcw;
        private System.Windows.Forms.RadioButton rbtn_silfor;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label lbl_mtsenser;
        private System.Windows.Forms.Label lbl_step;
        private System.Windows.Forms.Button btn_autopart2;
        private System.Windows.Forms.RadioButton btn_motorstop;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_rnpback;
        private System.Windows.Forms.Label lbl_rnpfor;
        private System.Windows.Forms.RadioButton btn_rapback;
        private System.Windows.Forms.RadioButton btn_rnpfor;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_output2;
        private System.Windows.Forms.Button btn_rapauto;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Button btn_rapbonus;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Label lbl_input2;
    }
}

