﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;


namespace 메모장
{
    public partial class Form1: Form
    {
        private PrintDocument printDocument;
        public Form1()
        {
            InitializeComponent();
            printDocument = new PrintDocument();
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // 여기에 인쇄할 내용을 그린다
            e.Graphics.DrawString(textBox1.Text, textBox1.Font, Brushes.Black, new PointF(100, 100));
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void 새창ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = new Form();
            form.ShowDialog();// Modal 팝업 우선, 결과를 받아야만 돌아감
            form.Show();//Modaless 우선권 없음 일반창
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openfile = new OpenFileDialog())
            {
                
                //열기의 팝업창에서 다룰 수 있는 확장자 설정
                openfile.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

                //show dialog는 열기 팝업창을 띄우면서 DialogResult를 반환한다.
                if (openfile.ShowDialog() == DialogResult.OK)
                {
                //파일이름 -> 바탕화면 C# 기초
                    textBox1.Text = File.ReadAllText(openfile.FileName);
                }
            }
        }

        private void 저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog savefile = new SaveFileDialog())
            {

                //저장 팝업창에서 다룰 수 있는 확장자 설정
                savefile.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

                //show dialog는 저장 팝업창을 띄우면서 DialogResult를 반환한다.
                if (savefile.ShowDialog() == DialogResult.OK)
                {
                    //파일이름, 컨텐츠 = textbox에 있는 text
                    File.WriteAllText(savefile.FileName, textBox1.Text);
                }
            }
        }

        private void 종료ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 인쇄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (PrintDialog pd = new PrintDialog())
            {
                pd.Document = printDocument;


                //show dialog는 열기 팝업창을 띄우면서 DialogResult를 반환한다.
                if (pd.ShowDialog() == DialogResult.OK)
                {
                    //파일이름 -> 바탕화면 C# 기초
                    printDocument.Print();
                }
            }
        }
    }
}
