﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 연산자
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 123;
            a *= a;
            int b = 123 * 123;
            Console.WriteLine(a);
            Console.WriteLine(b);   
        }
    }
}
