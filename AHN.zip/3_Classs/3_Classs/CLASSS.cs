﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_Classs
{

    class Animal
    {
        public virtual void speak()//1. 접근 키워드 2. 버츄얼 오버라이드 3. 반환형 4. 메서드 이름()
        {
            Console.WriteLine("짐승이 소리냅니다.");

        }
    }
    class Cat:Animal
    {
        public override void speak()
        {
            Console.WriteLine("냥냥이가 소리냅니다.");
        }
    }

    class Dog:Animal
    {
        public override void speak()
        {
            Console.WriteLine("멍멍이가 소리냅니다.");
        }
    }

    class Bird:Animal
    {
        public override void speak()
        {
            Console.WriteLine("쨲");
        }
    }
    class CLASSS
    {
    }
}
