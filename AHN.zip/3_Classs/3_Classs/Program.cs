﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_Classs
{
    class Program
    {
        static void Main(string[] args)
        {
            // 자식클래스에서 재정의된 메서드를 호출
            Animal animal1 = new Animal();
            animal1.speak();

            Animal animal = new Cat();
            animal.speak();

            Animal animal2 = new Dog();
            animal2.speak();
            
            Animal animal3 = new Bird();
            animal3.speak();
            // 랄라랄라라 랄라랄랄라 랄라랄라랄라
        }
    }
}
