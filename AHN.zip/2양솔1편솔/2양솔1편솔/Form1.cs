﻿using CIFX_50RE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace _2양솔1편솔
{
    public partial class Form1 : Form
    {
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        int Auto = 0;
        int sequenceStep = 0;
        bool isWaiting = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer2.Interval = 500;
            timer2.Tick += timer2_Tick;
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.Blue;
                timer1.Interval = 300;
                timer1.Start();

            }
            else
            {
                label3.Text = "NG";
                label3.ForeColor = Color.Red;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label3.Text == "OK")
            {
                Readdata = CIFX.xChannelRead();
                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                label6.Text = ReadDataConv;
                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                label7.Text = WritedataConv;
                label9.Text = ReadDataConv[6] == '1' ? "전진" : "후진";
                label10.Text = ReadDataConv[4] == '1' ? "전진" : "후진";
                label12.Text = ReadDataConv[2] == '1' ? "전진" : "후진";
            }


        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x01;
            Writedata[0] &= unchecked((byte)~0x02); // A-
            CIFX.xChannelWrite(Writedata);
            button1.Text = "수동운전";
            button1.BackColor = Color.White;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x02; // A-
            Writedata[0] &= unchecked((byte)~0x01); // A+
            CIFX.xChannelWrite(Writedata);
            button1.Text = "수동운전";
            button1.BackColor = Color.White;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x04; // B+
            Writedata[0] &= unchecked((byte)~0x08); // B-
            CIFX.xChannelWrite(Writedata);
            button1.Text = "수동운전";
            button1.BackColor = Color.White;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x08; // B-
            Writedata[0] &= unchecked((byte)~0x04); // B+
            CIFX.xChannelWrite(Writedata);
            button1.Text = "수동운전";
            button1.BackColor = Color.White;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x10; // C+ ON
            Writedata[0] &= unchecked((byte)~0x20); // C- OFF
            CIFX.xChannelWrite(Writedata);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Text = "정지";
            Writedata[0] &= unchecked((byte)~0x01); // A+
            Writedata[0] &= unchecked((byte)~0x04); // B+
            Writedata[0] &= unchecked((byte)~0x10); // C+

            // 후진 신호 ON
            Writedata[0] |= 0x02; // A-
            Writedata[0] |= 0x08; // B-
            Writedata[0] |= 0x20; // C-

            CIFX.xChannelWrite(Writedata);
            button4.BackColor = Color.LightGray;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x20; // C- ON
            Writedata[0] &= unchecked((byte)~0x10); // C+ OFF
            CIFX.xChannelWrite(Writedata);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sequenceStep = 0;
            timer2.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Readdata = CIFX.xChannelRead();
            ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
            button1.Text = "자동운전";
            switch (sequenceStep)
            {
                case 0: // 1번 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x01;
                        Writedata[0] &= unchecked((byte)~0x02);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[6] == '1') // Bit 6
                    {
                        isWaiting = false;
                        sequenceStep++;
                    }
                    break;

                case 1: // 2번 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x04;
                        Writedata[0] &= unchecked((byte)~0x08);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[4] == '1') // Bit 4
                    {
                        isWaiting = false;
                        sequenceStep++;
                    }
                    break;

                case 2: // 3번 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x10;
                        Writedata[0] &= unchecked((byte)~0x20);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[2] == '1') // Bit 2
                    {
                        isWaiting = false;
                        sequenceStep++;
                    }
                    break;

                case 3: // 1번 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x02;
                        Writedata[0] &= unchecked((byte)~0x01);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[7] == '1') // Bit 7
                    {
                        isWaiting = false;
                        sequenceStep++;
                    }
                    break;

                case 4: // 2번 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x08;
                        Writedata[0] &= unchecked((byte)~0x04);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[5] == '1') // Bit 5
                    {
                        isWaiting = false;
                        sequenceStep++;
                    }
                    break;

                case 5: // 3번 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x20;
                        Writedata[0] &= unchecked((byte)~0x10);
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else if (ReadDataConv[3] == '1') // Bit 3
                    {
                        isWaiting = false;
                        sequenceStep = 0; // 처음으로 되돌아감
                    }
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer2.Stop();
            isWaiting = false;
            sequenceStep = 0;
            button1.Text = "정지";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
