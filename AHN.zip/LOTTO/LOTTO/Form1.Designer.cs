﻿namespace LOTTO
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.lblRank1 = new System.Windows.Forms.Label();
            this.lblRank2 = new System.Windows.Forms.Label();
            this.lblRank3 = new System.Windows.Forms.Label();
            this.lblRank4 = new System.Windows.Forms.Label();
            this.lblRank5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label16 = new System.Windows.Forms.Label();
            this.labelDraw1 = new System.Windows.Forms.Label();
            this.labelDraw2 = new System.Windows.Forms.Label();
            this.labelDraw3 = new System.Windows.Forms.Label();
            this.labelDraw4 = new System.Windows.Forms.Label();
            this.labelDraw5 = new System.Windows.Forms.Label();
            this.labelDraw6 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblFail = new System.Windows.Forms.Label();
            this.labelBonus = new System.Windows.Forms.Label();
            this.Stop = new System.Windows.Forms.Button();
            this.randombtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(358, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(713, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "니가 로또로 인생역전할 확율";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(163, 269);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(52, 35);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(157, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "당신의 Lotto 번호";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(221, 268);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(52, 35);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(279, 269);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(52, 35);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(337, 269);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(52, 35);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(395, 268);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(52, 35);
            this.textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(453, 268);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(52, 35);
            this.textBox6.TabIndex = 7;
            // 
            // lblRank1
            // 
            this.lblRank1.AutoSize = true;
            this.lblRank1.Location = new System.Drawing.Point(159, 700);
            this.lblRank1.Name = "lblRank1";
            this.lblRank1.Size = new System.Drawing.Size(47, 24);
            this.lblRank1.TabIndex = 8;
            this.lblRank1.Text = "1등";
            // 
            // lblRank2
            // 
            this.lblRank2.AutoSize = true;
            this.lblRank2.Location = new System.Drawing.Point(275, 700);
            this.lblRank2.Name = "lblRank2";
            this.lblRank2.Size = new System.Drawing.Size(47, 24);
            this.lblRank2.TabIndex = 10;
            this.lblRank2.Text = "2등";
            // 
            // lblRank3
            // 
            this.lblRank3.AutoSize = true;
            this.lblRank3.Location = new System.Drawing.Point(380, 700);
            this.lblRank3.Name = "lblRank3";
            this.lblRank3.Size = new System.Drawing.Size(47, 24);
            this.lblRank3.TabIndex = 11;
            this.lblRank3.Text = "3등";
            // 
            // lblRank4
            // 
            this.lblRank4.AutoSize = true;
            this.lblRank4.Location = new System.Drawing.Point(492, 700);
            this.lblRank4.Name = "lblRank4";
            this.lblRank4.Size = new System.Drawing.Size(47, 24);
            this.lblRank4.TabIndex = 12;
            this.lblRank4.Text = "4등";
            // 
            // lblRank5
            // 
            this.lblRank5.AutoSize = true;
            this.lblRank5.Location = new System.Drawing.Point(616, 700);
            this.lblRank5.Name = "lblRank5";
            this.lblRank5.Size = new System.Drawing.Size(47, 24);
            this.lblRank5.TabIndex = 13;
            this.lblRank5.Text = "5등";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 736);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 24);
            this.label9.TabIndex = 14;
            this.label9.Text = "소비금";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(160, 778);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(324, 134);
            this.button1.TabIndex = 16;
            this.button1.Text = "구매 시작";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(724, 222);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 24);
            this.label15.TabIndex = 21;
            this.label15.Text = "Lotto 번호";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(714, 501);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 24);
            this.label16.TabIndex = 25;
            this.label16.Text = "시간";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // labelDraw1
            // 
            this.labelDraw1.AutoSize = true;
            this.labelDraw1.Location = new System.Drawing.Point(725, 280);
            this.labelDraw1.Name = "labelDraw1";
            this.labelDraw1.Size = new System.Drawing.Size(71, 24);
            this.labelDraw1.TabIndex = 27;
            this.labelDraw1.Text = "번호1";
            this.labelDraw1.Click += new System.EventHandler(this.label18_Click);
            // 
            // labelDraw2
            // 
            this.labelDraw2.AutoSize = true;
            this.labelDraw2.Location = new System.Drawing.Point(813, 280);
            this.labelDraw2.Name = "labelDraw2";
            this.labelDraw2.Size = new System.Drawing.Size(71, 24);
            this.labelDraw2.TabIndex = 28;
            this.labelDraw2.Text = "번호2";
            // 
            // labelDraw3
            // 
            this.labelDraw3.AutoSize = true;
            this.labelDraw3.Location = new System.Drawing.Point(901, 280);
            this.labelDraw3.Name = "labelDraw3";
            this.labelDraw3.Size = new System.Drawing.Size(71, 24);
            this.labelDraw3.TabIndex = 29;
            this.labelDraw3.Text = "번호3";
            // 
            // labelDraw4
            // 
            this.labelDraw4.AutoSize = true;
            this.labelDraw4.Location = new System.Drawing.Point(989, 280);
            this.labelDraw4.Name = "labelDraw4";
            this.labelDraw4.Size = new System.Drawing.Size(71, 24);
            this.labelDraw4.TabIndex = 30;
            this.labelDraw4.Text = "번호4";
            // 
            // labelDraw5
            // 
            this.labelDraw5.AutoSize = true;
            this.labelDraw5.Location = new System.Drawing.Point(1080, 280);
            this.labelDraw5.Name = "labelDraw5";
            this.labelDraw5.Size = new System.Drawing.Size(71, 24);
            this.labelDraw5.TabIndex = 31;
            this.labelDraw5.Text = "번호5";
            // 
            // labelDraw6
            // 
            this.labelDraw6.AutoSize = true;
            this.labelDraw6.Location = new System.Drawing.Point(1168, 280);
            this.labelDraw6.Name = "labelDraw6";
            this.labelDraw6.Size = new System.Drawing.Size(71, 24);
            this.labelDraw6.TabIndex = 32;
            this.labelDraw6.Text = "번호6";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(160, 662);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(106, 24);
            this.lblTotal.TabIndex = 33;
            this.lblTotal.Text = "시도횟수";
            // 
            // lblFail
            // 
            this.lblFail.AutoSize = true;
            this.lblFail.Location = new System.Drawing.Point(738, 700);
            this.lblFail.Name = "lblFail";
            this.lblFail.Size = new System.Drawing.Size(58, 24);
            this.lblFail.TabIndex = 34;
            this.lblFail.Text = "낙첨";
            // 
            // labelBonus
            // 
            this.labelBonus.AutoSize = true;
            this.labelBonus.Location = new System.Drawing.Point(812, 343);
            this.labelBonus.Name = "labelBonus";
            this.labelBonus.Size = new System.Drawing.Size(72, 24);
            this.labelBonus.TabIndex = 35;
            this.labelBonus.Text = "bonus";
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(607, 778);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(240, 134);
            this.Stop.TabIndex = 36;
            this.Stop.Text = "일시정지";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // randombtn
            // 
            this.randombtn.Location = new System.Drawing.Point(367, 203);
            this.randombtn.Name = "randombtn";
            this.randombtn.Size = new System.Drawing.Size(154, 43);
            this.randombtn.TabIndex = 37;
            this.randombtn.Text = "랜덤구매";
            this.randombtn.UseVisualStyleBackColor = true;
            this.randombtn.Click += new System.EventHandler(this.randombtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(714, 343);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 24);
            this.label3.TabIndex = 38;
            this.label3.Text = "보너스";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(454, 322);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(52, 35);
            this.textBox12.TabIndex = 44;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(396, 322);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(52, 35);
            this.textBox11.TabIndex = 43;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(338, 323);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(52, 35);
            this.textBox10.TabIndex = 42;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(280, 323);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(52, 35);
            this.textBox9.TabIndex = 41;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(222, 322);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(52, 35);
            this.textBox8.TabIndex = 40;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(164, 323);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(52, 35);
            this.textBox7.TabIndex = 39;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(455, 428);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(52, 35);
            this.textBox24.TabIndex = 56;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(397, 428);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(52, 35);
            this.textBox23.TabIndex = 55;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(339, 429);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(52, 35);
            this.textBox22.TabIndex = 54;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(281, 429);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(52, 35);
            this.textBox21.TabIndex = 53;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(223, 428);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(52, 35);
            this.textBox20.TabIndex = 52;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(165, 429);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(52, 35);
            this.textBox19.TabIndex = 51;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(454, 374);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(52, 35);
            this.textBox18.TabIndex = 50;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(396, 374);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(52, 35);
            this.textBox17.TabIndex = 49;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(338, 375);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(52, 35);
            this.textBox16.TabIndex = 48;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(280, 375);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(52, 35);
            this.textBox15.TabIndex = 47;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(222, 374);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(52, 35);
            this.textBox14.TabIndex = 46;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(164, 375);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(52, 35);
            this.textBox13.TabIndex = 45;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(455, 489);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(52, 35);
            this.textBox30.TabIndex = 62;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(397, 489);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(52, 35);
            this.textBox29.TabIndex = 61;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(339, 490);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(52, 35);
            this.textBox28.TabIndex = 60;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(281, 490);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(52, 35);
            this.textBox27.TabIndex = 59;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(223, 489);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(52, 35);
            this.textBox26.TabIndex = 58;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(165, 490);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(52, 35);
            this.textBox25.TabIndex = 57;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("굴림", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(970, 778);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(308, 134);
            this.button2.TabIndex = 63;
            this.button2.Text = "인생리셋";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(438, 736);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(82, 24);
            this.label33.TabIndex = 64;
            this.label33.Text = "당첨금";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(727, 736);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(106, 24);
            this.label44.TabIndex = 65;
            this.label44.Text = "통장잔고";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 1001);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.randombtn);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.labelBonus);
            this.Controls.Add(this.lblFail);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.labelDraw6);
            this.Controls.Add(this.labelDraw5);
            this.Controls.Add(this.labelDraw4);
            this.Controls.Add(this.labelDraw3);
            this.Controls.Add(this.labelDraw2);
            this.Controls.Add(this.labelDraw1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblRank5);
            this.Controls.Add(this.lblRank4);
            this.Controls.Add(this.lblRank3);
            this.Controls.Add(this.lblRank2);
            this.Controls.Add(this.lblRank1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label lblRank1;
        private System.Windows.Forms.Label lblRank2;
        private System.Windows.Forms.Label lblRank3;
        private System.Windows.Forms.Label lblRank4;
        private System.Windows.Forms.Label lblRank5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelDraw1;
        private System.Windows.Forms.Label labelDraw2;
        private System.Windows.Forms.Label labelDraw3;
        private System.Windows.Forms.Label labelDraw4;
        private System.Windows.Forms.Label labelDraw5;
        private System.Windows.Forms.Label labelDraw6;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblFail;
        private System.Windows.Forms.Label labelBonus;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button randombtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label44;
    }
}

