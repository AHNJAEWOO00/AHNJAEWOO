﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static LOTTO.Form1;

namespace LOTTO
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();

            gameTextBoxes = new List<List<TextBox>>
    {
        new List<TextBox> { textBox1,  textBox2,  textBox3,  textBox4,  textBox5,  textBox6  },
        new List<TextBox> { textBox7,  textBox8,  textBox9,  textBox10, textBox11, textBox12 },
        new List<TextBox> { textBox13, textBox14, textBox15, textBox16, textBox17, textBox18 },
        new List<TextBox> { textBox19, textBox20, textBox21, textBox22, textBox23, textBox24 },
        new List<TextBox> { textBox25, textBox26, textBox27, textBox28, textBox29, textBox30 }
    };
        }
        private List<List<TextBox>> gameTextBoxes;
        private int weeksPassed = 0;
        private int yearsPassed = 0;
        List<int> myLottoNumbers = new List<int>();
        int weeks = 0;  // 경과된 주
        int years = 0;  // 경과된 년도
        Random random = new Random();
        int[] rankCount = new int[6]; // 1등~5등, 꽝
        int totalTries = 0;
        LottoSimulator lottoSimulator = new LottoSimulator();
        private int balance = 0;
        private int totalSpent = 0;
        private int totalWinnings = 0;
        private void btnStart_Click(object sender, EventArgs e)
        {
            var numbers = GetMyLottoNumbers();

            if (numbers != null)
            {
                myLottoNumbers = numbers;
                totalTries = 0;
                Array.Clear(rankCount, 0, rankCount.Length);
                StartLottoTimer();
            }
        }
        private List<int> GetMyLottoNumbers()
        {
            List<TextBox> textBoxes = new List<TextBox>
    {
        textBox1, textBox2, textBox3, textBox4, textBox5, textBox6
    };

            List<int> numbers = new List<int>();

            foreach (var tb in textBoxes)
            {
                if (int.TryParse(tb.Text, out int number) && number >= 1 && number <= 45)
                {
                    if (!numbers.Contains(number))
                    {
                        numbers.Add(number);
                    }
                    else
                    {
                        MessageBox.Show("중복된 숫자가 있습니다!");
                        return null;
                    }
                }
                else
                {
                    MessageBox.Show("1부터 45 사이의 숫자를 입력하세요!");
                    return null;
                }
            }

            return numbers;
        }

        private void StartLottoTimer()
        {
            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 20; // 20ms
            timer1.Tick += Timer_Tick;
            timer1.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateStatsDisplay();
            int netBalance = totalWinnings - totalSpent;
            label44.Text = $"통장잔고: {netBalance:N0}원";
            int drawCount = 5;
            int weeklyCost = 1000 * drawCount; // 매주 5000원 (1게임에 1000원 * 5게임)
            label9.Text = $"총 지출: {totalSpent:N0}원";
            label33.Text = $"총 당첨금: {totalWinnings:N0}원";
            balance -= weeklyCost; // 매주 비용 차감

            for (int i = 0; i < drawCount; i++)
            {
                var myNumbers = GetLottoNumbersFromTextBoxes(gameTextBoxes[i]);
                if (myNumbers == null) return;

                lottoSimulator.RunDraw(myNumbers);
                UpdateBalance(lottoSimulator.LastRank); // 결과에 따른 보상 적용
                totalTries++;
            }

            // 1틱당 5게임 → 5주 경과
            weeksPassed += 5;
            if (weeksPassed >= 52)
            {
                yearsPassed++;
                weeksPassed -= 52;
                label16.Text = $"경과한 년수: {yearsPassed}년";
            }

            // 마지막 draw 결과 표시 (1게임 기준)
            var drawNumbers = lottoSimulator.LastDrawNumbers;
            var bonus = lottoSimulator.BonusNumber;

            labelDraw1.Text = drawNumbers[0].ToString();
            labelDraw2.Text = drawNumbers[1].ToString();
            labelDraw3.Text = drawNumbers[2].ToString();
            labelDraw4.Text = drawNumbers[3].ToString();
            labelDraw5.Text = drawNumbers[4].ToString();
            labelDraw6.Text = drawNumbers[5].ToString();
            labelBonus.Text = bonus.ToString();

            // 통계 및 자산 표시
            lblTotal.Text = $"총 시도 횟수: {lottoSimulator.TotalTries:N0}";
            lblRank1.Text = $"1등: {lottoSimulator.RankCount[0]:N0}";
            lblRank2.Text = $"2등: {lottoSimulator.RankCount[1]:N0}";
            lblRank3.Text = $"3등: {lottoSimulator.RankCount[2]:N0}";
            lblRank4.Text = $"4등: {lottoSimulator.RankCount[3]:N0}";
            lblRank5.Text = $"5등: {lottoSimulator.RankCount[4]:N0}";
            lblFail.Text = $"꽝: {lottoSimulator.RankCount[5]:N0}";
            label9.Text = $"소비금액: {balance:N0}원";
        }

        private List<int> GetLottoNumbersFromTextBoxes(List<TextBox> textBoxes)
        {
            List<int> numbers = new List<int>();

            foreach (var tb in textBoxes)
            {
                if (!int.TryParse(tb.Text, out int number) || number < 1 || number > 45)
                {
                    timer1.Stop();  // 타이머 중단
                    MessageBox.Show("1부터 45 사이의 숫자를 입력하세요!");
                    return null;
                }

                if (numbers.Contains(number))
                {
                    timer1.Stop();  // 타이머 중단
                    MessageBox.Show("중복된 숫자가 있습니다!");
                    return null;
                }

                numbers.Add(number);
            }

            return numbers;
        }


        public class LottoSimulator
        {
            public int LastRank { get; private set; } = 5;  // 기본은 꽝
            private Random random = new Random();
            public int TotalTries { get; private set; } = 0;
            public int[] RankCount { get; private set; } = new int[6]; // 1~5등 + 꽝
            public int BonusNumber { get; private set; }
            public List<int> LastDrawNumbers { get; private set; } = new List<int>();

            public void RunDraw(List<int> myNumbers)
            {
                TotalTries++;

                // 당첨 번호를 랜덤으로 생성
                var drawNumbers = new HashSet<int>();
                while (drawNumbers.Count < 6)
                    drawNumbers.Add(random.Next(1, 46));

                int bonus;
                do
                {
                    bonus = random.Next(1, 46);
                } while (drawNumbers.Contains(bonus));

                BonusNumber = bonus;
                LastDrawNumbers = drawNumbers.ToList();
                LastDrawNumbers.Sort(); // 당첨 번호 정렬

                myNumbers.Sort(); // 사용자가 입력한 번호 정렬

                // 등수 판별
                int match = myNumbers.Count(n => drawNumbers.Contains(n));
                bool bonusMatch = myNumbers.Contains(bonus);

                int rank = 5; // 기본은 꽝
                if (match == 6) rank = 0; // 1등
                else if (match == 5 && bonusMatch) rank = 1; // 2등
                else if (match == 5) rank = 2; // 3등
                else if (match == 4) rank = 3; // 4등
                else if (match == 3) rank = 4; // 5등

                RankCount[rank]++;
           
                LastRank = rank;
            }
        }
        private void UpdateStatsDisplay()
        {
            lblTotal.Text = $"총 시도 횟수: {lottoSimulator.TotalTries:N0}";
            lblRank1.Text = $"1등: {lottoSimulator.RankCount[0]:N0}";
            lblRank2.Text = $"2등: {lottoSimulator.RankCount[1]:N0}";
            lblRank3.Text = $"3등: {lottoSimulator.RankCount[2]:N0}";
            lblRank4.Text = $"4등: {lottoSimulator.RankCount[3]:N0}";
            lblRank5.Text = $"5등: {lottoSimulator.RankCount[4]:N0}";
            lblFail.Text = $"꽝: {lottoSimulator.RankCount[5]:N0}";

            label9.Text = $"총 지출: {totalSpent:N0}원";
            label33.Text = $"총 당첨금: {totalWinnings:N0}원";
            label44.Text = $"통장잔고: {(totalWinnings - totalSpent):N0}원";
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnStart_Click(sender, e);
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled) // 타이머가 작동 중이라면
            {
                // 타이머 멈추기
                timer1.Stop();
                Stop.Invoke((MethodInvoker)(() => Stop.Text = "재개")); // UI에서 텍스트 변경
            }
            else
            {
                // 타이머 다시 시작
                timer1.Start();
                Stop.Invoke((MethodInvoker)(() => Stop.Text = "일시정지")); // UI에서 텍스트 변경
            }
        }

        private void UpdateBalance(int rank)
        {
            balance -= 1000;
            totalSpent += 1000;

            switch (rank)
            {
                case 0:
                    balance += 2000000000;
                    totalWinnings += 2000000000;
                    break;
                case 1:
                    balance += 90000000;
                    totalWinnings += 90000000;
                    break;
                case 2:
                    balance += 1500000;
                    totalWinnings += 1500000;
                    break;
                case 3:
                    balance += 50000;
                    totalWinnings += 50000;
                    break;
                case 4:
                    balance += 5000;
                    totalWinnings += 5000;
                    break;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void lblBalance_Click(object sender, EventArgs e)
        {

        }

        private void randombtn_Click(object sender, EventArgs e)
        {
            Random random = new Random();

            foreach (var game in gameTextBoxes)
            {
                HashSet<int> randomNumbers = new HashSet<int>();

                // 중복 없이 6개 번호 생성
                while (randomNumbers.Count < 6)
                {
                    int number = random.Next(1, 46); // 1~45 사이
                    randomNumbers.Add(number);
                }

                List<int> sortedNumbers = randomNumbers.ToList();
                sortedNumbers.Sort();

                // 각 텍스트박스에 할당
                for (int i = 0; i < 6; i++)
                {
                    game[i].Text = sortedNumbers[i].ToString();
                }
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 1. 타이머 중지
            if (timer1 != null && timer1.Enabled)
                timer1.Stop();

            // 2. 모든 TextBox 초기화
            foreach (var game in gameTextBoxes)
            {
                foreach (var tb in game)
                {
                    tb.Text = "";
                }
            }

            // 3. 변수 초기화
            weeksPassed = 0;
            yearsPassed = 0;
            balance = 0;
            totalTries = 0;
            myLottoNumbers.Clear();
            Array.Clear(rankCount, 0, rankCount.Length);
            lottoSimulator = new LottoSimulator(); // 새로 생성해서 내부 통계 초기화

            // 4. 라벨 초기화
            label16.Text = "경과한 년수: 0년";
            labelDraw1.Text = "";
            labelDraw2.Text = "";
            labelDraw3.Text = "";
            labelDraw4.Text = "";
            labelDraw5.Text = "";
            labelDraw6.Text = "";
            labelBonus.Text = "";
            lblTotal.Text = "총 시도 횟수: 0";
            lblRank1.Text = "1등: 0";
            lblRank2.Text = "2등: 0";
            lblRank3.Text = "3등: 0";
            lblRank4.Text = "4등: 0";
            lblRank5.Text = "5등: 0";
            lblFail.Text = "꽝: 0";
            totalSpent = 0;
            totalWinnings = 0;
            label44.Text = "통장잔고: 0원";
            label9.Text = "총 지출: 0원";
            label33.Text = "총 당첨금: 0원";
            Stop.Text = "일시정지"; // 재개 상태라면 버튼 텍스트도 초기화
        }

        private void label33_Click(object sender, EventArgs e)
        {

        }
    }
}
