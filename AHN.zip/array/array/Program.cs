﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            //자료형 대괄호 변수 = new 자료형[배열의 크기] / 오른쪽 대괄호만큼의 공간이 생김 / 자동 초기값은 0이다.
            int[] number = new int[6];




            //Console.WriteLine(number[0]);
            //Console.WriteLine(num[0]);
            //Console.WriteLine(num[1]);
            //Console.WriteLine(num[2]);
            //Console.WriteLine(num[3]);
            //Console.WriteLine(num[4]);
            //배열 범위를 벗어나면 인덱스 오류가 난다.
            //Console.WriteLine(num[5]);


            number[0] = 10;
            number[1] = 11;
            number[2] = 12;
            number[3] = 13;
            number[4] = 14;
            
            Console.WriteLine(number[0]);
            Console.WriteLine(number[1]);
            Console.WriteLine(number[2]);
            Console.WriteLine(number[3]);   
            Console.WriteLine(number[4]);
            Console.WriteLine(number[5]);

            number[0] = 100;

            Console.WriteLine(number[0]);


            // 문자열 배열 자료형 선언법
            string[] lang = new string[5];

            //문자열 배열 자료형 초기화
            string[] langs = { "파이썬", "C#", "JAVA","한국어", "영어" };
            

            //문자열의 공백은 0이아닌 빈칸이다.
            Console.WriteLine(lang);
            Console.WriteLine(langs[0]);

            Console.WriteLine(langs);
            Console.WriteLine(langs[0]);


            langs[0] = "C언어";
            Console.WriteLine(langs[0]);


            string sublang = langs[0].Substring(0);
            Console.WriteLine(sublang);


            int arraylen = langs.Length;
            Console.WriteLine(arraylen);


            Console.WriteLine();
            Console.WriteLine();


            //정수형 자료형 초기화 배열
            int[] num = { 3, 2, 5, 1, 4 };
            
            Array.Sort(num);//정렬 오름차순
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i]);
            }

            Console.WriteLine();

            Array.Reverse(num);//정렬 내림차순
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i]);
            }

            Console.WriteLine();
            Console.WriteLine();


            //2차원 배열 선언
            int[,]  secarray = new int[3, 3];
            //2차원 배열 초기화
            int[,] 숫자배열 = new int[,]
                { 
                    {1,2,3}, 
                    {4,5,6}, 
                    {7,8,9} 
                };
            int 첫번째 = 숫자배열[0, 0];
            int 두번째 = 숫자배열[1, 2];
            Console.WriteLine(첫번째);
            Console.WriteLine(두번째);

            //가변 배열

            Console.WriteLine();
            Console.WriteLine();    


            int[][] 가변배열 = new int[3][];
            가변배열[0] = new int[] { 1, 2 };
            가변배열[1] = new int[] { 3, 4, 5 };
            가변배열[2] = new int[] { 6, 7, 8, 9 };

            int 첫가변배열 = 가변배열[0][1];//1번층 두번째칸
            int 세가변배열 = 가변배열[2][2];//3번층 세번째칸
            
            Console.WriteLine(첫가변배열);
            Console.WriteLine(세가변배열);



        }
    }
}
