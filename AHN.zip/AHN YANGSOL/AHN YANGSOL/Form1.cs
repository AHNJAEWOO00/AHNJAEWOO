﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;


namespace AHN_YANGSOL
{
    public partial class Form1 : Form
    {
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];

        int Auto = 0;
        string ReaddataConv = "00000000";
        private string WritedataConv;


        int autoStep = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label3.Text = "Okey";
                label3.ForeColor = Color.Blue;
                timer1.Interval = 1000;
                timer1.Start();
            }
            else
            {
                label3.Text = "Not Good";
                label3.ForeColor = Color.Red;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label3.Text == "Okey")
            {
                Readdata = CIFX.xChannelRead();
                ReaddataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                label7.Text = ReaddataConv[6] == '1' ? "전진" : "후진";
                label14.Text = ReaddataConv[4] == '1' ? "전진" : "후진";
                label10.Text = ReaddataConv;
                label11.Text = WritedataConv;
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                Writedata[0] |= 0x01;  // 비트 0 (0x01) ON (1번 실린더 켜기)
            else
                Writedata[0] &= 0xFE;  // 비트 0 (0x01) OFF (1번 실린더 끄기)

            CIFX.xChannelWrite(Writedata);



            //Writedata[0] = 0x01;
            //CIFX.xChannelWrite(Writedata);
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
                Writedata[0] &= 0xFE;  // 비트 0 (0x01) OFF (1번 실린더 끄기)

            CIFX.xChannelWrite(Writedata);



            //Writedata[0] ^= 0x01;
            //CIFX.xChannelWrite(Writedata);//1실린더 전후진
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton3.Checked)
            {
                Writedata[0] |= 0x02;  // 비트 1 (0x02) ON (2번 실린더 전진)
                Writedata[0] &= 0xFB;  // 비트 2 (0x04) OFF (2번 실린더 후진 해제)
            }

            CIFX.xChannelWrite(Writedata);



            //  Writedata[0] ^= 0x02;
            //  CIFX.xChannelWrite(Writedata);//2실린더 전진
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                Writedata[0] |= 0x04;  // 비트 2 (0x04) ON (2번 실린더 후진)
                Writedata[0] &= 0xFD;  // 비트 1 (0x02) OFF (2번 실린더 전진 해제)
            }

            CIFX.xChannelWrite(Writedata);





            // Writedata[0] ^= 0x04;
            // CIFX.xChannelWrite(Writedata);//2실린더 후진
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 모든 실린더 후진 상태로 초기화
            Writedata[0] &= 0xFE; // 1번 실린더 OFF (bit 0)
            Writedata[0] &= 0xFD; // 2번 실린더 전진 OFF (bit 1)
            Writedata[0] |= 0x04; // 2번 실린더 후진 ON (bit 2)

            CIFX.xChannelWrite(Writedata);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            autoStep = 0;
            timer2.Interval = 500; // 1초 간격
            timer2.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 자동 시퀀스 타이머 정지
            timer2.Stop();

            // 모든 실린더 동작 중지 (비트 OFF)
            Writedata[0] &= 0xF8; // Bit 0~2 OFF (0000 0111 -> 반전 = 1111 1000)
            CIFX.xChannelWrite(Writedata);

            MessageBox.Show("자동운전이 중지되었습니다.", "중지");
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (autoStep)
            {
                case 0:
                    // 1번 실린더 전진
                    Writedata[0] |= 0x01;
                    // 2번 실린더 전진
                    Writedata[0] |= 0x02;
                    Writedata[0] &= 0xFB;
                    CIFX.xChannelWrite(Writedata);
                    break;

                case 1:
                    // 1번 실린더 후진
                    Writedata[0] &= 0xFE;
                  
                    CIFX.xChannelWrite(Writedata);
                    break;

                case 2:
                    // 2번 실린더 후진
                    Writedata[0] |= 0x04;
                    Writedata[0] &= 0xFD;
                    CIFX.xChannelWrite(Writedata);
                    break;

                case 3:
                    CIFX.xChannelWrite(Writedata);
                    break;
            }

            autoStep = (autoStep + 1) % 4; // 0 → 1 → 2 → 3 → 0 → ...
        }
    }

}