﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;

namespace 실린더백개
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        int Auto = 0;
        int sequenceStep = 0;
        bool isWaiting = false;
        int targetCycleCount = 0; // 목표 반복 횟수
        int currentCycleCount = 0; // 현재 진행 중인 반복 횟수














        private void Form1_Load(object sender, EventArgs e)
        {
            timer2.Interval = 500;
            timer2.Tick += timer2_Tick;
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                button6.Text = "Communication OK";
                button6.ForeColor = Color.Blue;
                button6.BackColor = Color.Pink;
                timer1.Interval = 200;
                timer1.Start();

            }
            else
            {
                button6.Text = "NG";
                button6.ForeColor = Color.Red;
                button6.BackColor = Color.White;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Readdata = CIFX.xChannelRead();
            ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
            WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
            label5.Text = ReadDataConv;
            label7.Text = WritedataConv;

            // A 실린더
            label9.BackColor = (Readdata[18] & 0x02) != 0 ? Color.GreenYellow : Color.White; // A 전진 감지
            label8.BackColor = (Readdata[18] & 0x01) != 0 ? Color.GreenYellow : Color.White; // A 후진 감지

            // B 실린더
            label10.BackColor = (Readdata[18] & 0x08) != 0 ? Color.GreenYellow : Color.White; // B 전진 감지
            label11.BackColor = (Readdata[18] & 0x04) != 0 ? Color.GreenYellow : Color.White; // B 후진 감지

            // C 실린더
            label12.BackColor = (Readdata[18] & 0x20) != 0 ? Color.GreenYellow : Color.White; // C 전진 감지
            label13.BackColor = (Readdata[18] & 0x10) != 0 ? Color.GreenYellow : Color.White; // C 후진 감지
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x01;
            Writedata[0] &= unchecked((byte)~0x02); // A-
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x02; // A-
            Writedata[0] &= unchecked((byte)~0x01); // A+
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x04; // B+
            Writedata[0] &= unchecked((byte)~0x08); // B-
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x08; // B-
            Writedata[0] &= unchecked((byte)~0x04); // B+
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x10; // C+ ON
            Writedata[0] &= unchecked((byte)~0x20); // C- OFF
            CIFX.xChannelWrite(Writedata);
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x20; // C- ON
            Writedata[0] &= unchecked((byte)~0x10); // C+ OFF
            CIFX.xChannelWrite(Writedata);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Writedata[0] &= unchecked((byte)~0x01); // A+
            Writedata[0] &= unchecked((byte)~0x04); // B+
            Writedata[0] &= unchecked((byte)~0x10); // C+

            // 후진 신호 ON
            Writedata[0] |= 0x02; // A-
            Writedata[0] |= 0x08; // B-
            Writedata[0] |= 0x20; // C-

            CIFX.xChannelWrite(Writedata);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer2.Stop();
            isWaiting = false;
            sequenceStep = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            targetCycleCount = int.MaxValue; // 무한모드라면
            currentCycleCount = 0;
            sequenceStep = 0;
            isWaiting = false;
            label16.Text = "동작 횟수: 0"; // ✅ 여기 추가!
            timer2.Start();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (sequenceStep)
            {
                case 0: // 1동작: A 전진 + C 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x01; // A+ ON
                        Writedata[0] |= 0x10; // C+ ON
                        Writedata[0] &= unchecked((byte)~0x02); // A- OFF
                        Writedata[0] &= unchecked((byte)~0x20); // C- OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x02) != 0 && (Readdata[18] & 0x20) != 0)
                        {
                            isWaiting = false;
                            sequenceStep++;
                        }
                    }
                    break;

                case 1: // 2동작: C 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x20; // C- ON
                        Writedata[0] &= unchecked((byte)~0x10); // C+ OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x10) != 0) // C 후진 감지
                        {
                            isWaiting = false;
                            sequenceStep++;
                        }
                    }
                    break;

                case 2: // 3동작: A 후진 + B 전진 + C 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x02; // A- ON
                        Writedata[0] |= 0x04; // B+ ON
                        Writedata[0] |= 0x10; // C+ ON
                        Writedata[0] &= unchecked((byte)~0x01); // A+ OFF
                        Writedata[0] &= unchecked((byte)~0x08); // B- OFF
                        Writedata[0] &= unchecked((byte)~0x20); // C- OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x01) != 0 && (Readdata[18] & 0x08) != 0 && (Readdata[18] & 0x20) != 0)
                        {
                            isWaiting = false;
                            sequenceStep++;
                        }
                    }
                    break;

                case 3: // 4동작: C 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x20; // C- ON
                        Writedata[0] &= unchecked((byte)~0x10); // C+ OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x10) != 0) // C 후진 감지
                        {
                            isWaiting = false;
                            sequenceStep++;
                        }
                    }
                    break;

                case 4: // 5동작: A 전진 + B 후진 + C 전진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x01; // A+ ON
                        Writedata[0] |= 0x08; // B- ON
                        Writedata[0] |= 0x10; // C+ ON
                        Writedata[0] &= unchecked((byte)~0x02); // A- OFF
                        Writedata[0] &= unchecked((byte)~0x04); // B+ OFF
                        Writedata[0] &= unchecked((byte)~0x20); // C- OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x02) != 0 && (Readdata[18] & 0x04) != 0 && (Readdata[18] & 0x20) != 0)
                        {
                            isWaiting = false;
                            sequenceStep++;
                        }
                    }
                    break;

                case 5: // 6동작: A 후진 + C 후진
                    if (!isWaiting)
                    {
                        Writedata[0] |= 0x02; // A- ON
                        Writedata[0] |= 0x20; // C- ON
                        Writedata[0] &= unchecked((byte)~0x01); // A+ OFF
                        Writedata[0] &= unchecked((byte)~0x10); // C+ OFF
                        CIFX.xChannelWrite(Writedata);
                        isWaiting = true;
                    }
                    else
                    {
                        Readdata = CIFX.xChannelRead();
                        if ((Readdata[18] & 0x01) != 0 && (Readdata[18] & 0x10) != 0)
                        {
                            isWaiting = false;
                            currentCycleCount++;
                            label16.Text = $"동작 횟수: {currentCycleCount}";
                            if (currentCycleCount >= targetCycleCount)
                            {
                                timer2.Stop();
                                MessageBox.Show("자동 운전 완료!");
                            }
                            else
                            {
                                sequenceStep = 0; // 다시 처음부터
                            }
                        }
                    }
                    break;
            }
        }




        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            targetCycleCount = (int)numericUpDown1.Value;
            currentCycleCount = 0; // 새로운 값 입력 시 현재 카운트 초기화
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (targetCycleCount > 0)
            {
                sequenceStep = 0;
                isWaiting = false;
                currentCycleCount = 0;
                timer2.Start();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
