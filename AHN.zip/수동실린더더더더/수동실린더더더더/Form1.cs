﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;





namespace 수동실린더더더더
{
    public partial class Form1 : Form
    {
        //ECC Module read/write buffer define
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        string ReadDataConv; // 클래스 수준 변수로 선언
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label3.Text == "OK")
            {

                Readdata = CIFX.xChannelRead();

                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');

                if (ReadDataConv[7] == '1')
                { label5.Text = "ON"; }
                else if (ReadDataConv[7] == '0')
                { label5.Text = "OFF"; }
                if (ReadDataConv[6] == '1')
                { label7.Text = "ON"; }
                else if (ReadDataConv[6] == '0')
                { label7.Text = "OFF"; }

                if (ReadDataConv[5] == '1')
                { label9.Text = "ON"; }
                else if (ReadDataConv[5] == '0')
                { label9.Text = "OFF"; }
                if (ReadDataConv[4] == '1')
                { label11.Text = "ON"; }
                else if (ReadDataConv[4] == '0')
                { label11.Text = "OFF"; }
            }
        }
        // 실린더 1
        private void button1_Click(object sender, EventArgs e)
        {
        }
        }
        private void button2_Click(object sender, EventArgs e)
        {

        }
        // 실린더 2
        private void button3_Click(object sender, EventArgs e)
        {
        }
        private void button4_Click(object sender, EventArgs e)
        {
        }
        private void button5_Click(object sender, EventArgs e)//초기화
        {
        }

        private void button6_Click(object sender, EventArgs e)
        {
        }
        private void button7_Click(object sender, EventArgs e)
        {
            label3.Text = "해제됨";
            label3.ForeColor = Color.Red;
            timer1.Stop();//타이머 정지
            CIFX.close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect(); // connetct변수선언, CIFX함수안에
                                                // 컨넥트사용
            if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.LimeGreen;
                // 보드가 컨넥션되고, 타이머 구동(설정)
                timer1.Interval = (int)500;// 타이머 ms단위 0.5sec
                timer1.Start();
            }
            else
            {

                label1.Text = "NG";
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            label3.Text = "해제됨";
            label3.ForeColor = Color.Red;
            timer1.Stop();//타이머 정지
            CIFX.close();

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Writedata[0] = (byte)0x00;
            CIFX.xChannelWrite(Writedata);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            if (ReadDataConv[7] == '1')
            {
                Writedata[0] ^= 0x01; //전진
                CIFX.xChannelWrite(Writedata);

            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (ReadDataConv[6] == '1')
            {
                Writedata[0] ^= 0x01; //후진
                CIFX.xChannelWrite(Writedata);
            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (ReadDataConv[5] == '1')
            {
                Writedata[0] ^= 0x02; //전진
                CIFX.xChannelWrite(Writedata);
            }

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (ReadDataConv[4] == '1')
            {
                Writedata[0] ^= 0x02; //후진
                CIFX.xChannelWrite(Writedata);
            }

        }
    } 
}