﻿using CIFX_50RE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 양솔레이드2개제어하기
{
    public partial class Form1 : Form
    {
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        int Auto = 0;
        int stepCounter = 0;      // 현재 단계 (0~3)
        int sequenceCount = 0;    // 몇 바퀴 돌았는지
        bool isRunningSequence = false; // 실행 중인지
        int autoStep = 0;
        bool isAutoRunning = false;
        bool isPaused = false;
        bool isSequenceRunning = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                button1.Text = "Communication OK";
                button1.BackColor = Color.Pink;
                button1.ForeColor = Color.Blue;
                timer1.Interval = 300;
                timer1.Start();
                button1_Click(null, null);
            }
            else
            {
                button1.Text = "Communication NG";
                button1.BackColor = Color.White;
                button1.ForeColor = Color.Red;
            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (button1.Text == "Communication OK")
            {
                Readdata = CIFX.xChannelRead();
                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                label5.Text = ReadDataConv;
                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                label6.Text = WritedataConv;

                if (isAutoRunning)  // 자동 운전이 시작되었을 때만 작동
                {
                    switch (autoStep)
                    {
                        case 0: // A 전진
                            Writedata[0] |= 0x01;
                            Writedata[0] &= unchecked((byte)~0x02);
                            break;
                        case 1: // B 전진
                            Writedata[0] |= 0x04;
                            Writedata[0] &= unchecked((byte)~0x08);
                            break;
                        case 2: // A 후진
                            Writedata[0] |= 0x02;
                            Writedata[0] &= unchecked((byte)~0x01);
                            break;
                        case 3: // B 후진
                            Writedata[0] |= 0x08;
                            Writedata[0] &= unchecked((byte)~0x04);
                            break;
                    }

                    CIFX.xChannelWrite(Writedata);
                    autoStep = (autoStep + 1) % 4; // 다음 단계로 순환
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Writedata[0] |= 0x01;
            Writedata[0] &= unchecked((byte)~0x02); // A-
            CIFX.xChannelWrite(Writedata);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Writedata[0] |= 0x02; // A-
            Writedata[0] &= unchecked((byte)~0x01); // A+
            CIFX.xChannelWrite(Writedata);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Writedata[0] |= 0x04; // B+
            Writedata[0] &= unchecked((byte)~0x08); // B-
            CIFX.xChannelWrite(Writedata);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Writedata[0] |= 0x08; // B-
            Writedata[0] &= unchecked((byte)~0x04); // B+
            CIFX.xChannelWrite(Writedata);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            // 자동 운전이 시작되지 않았다면 시작
            if (!isAutoRunning)
            {
                isAutoRunning = true; // 자동 운전 시작
                autoStep = 0;  // 자동 운전 단계 초기화

                // 버튼 텍스트 변경
                button6.Text = "자동 운전 중";  // "자동 운전 중"으로 변경

                // Writedata 초기화 (자동 운전 시작 시 초기화)
                Writedata[0] = 0x00;  // 자동 운전 시작 시 초기화 (원하는 데이터 값으로 수정)
                CIFX.xChannelWrite(Writedata);

                // timer1 재시작 (자동 운전 시작)
                timer1.Start();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!isSequenceRunning)
            {
                stepCounter = 0;
                sequenceCount = 0;
                isSequenceRunning = true;
                timer2.Interval = 500; // 단계 간 딜레이 (ms)
                timer2.Start();
                
                isPaused = false;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            {
                // 자동 운전이 진행 중이라면 정지
                if (isAutoRunning)
                {
                    isAutoRunning = false;  // 자동 운전 정지
                    Writedata[0] = 0x00;  // 모든 신호를 초기화 (자동 운전 관련 초기화)
                    CIFX.xChannelWrite(Writedata);

                    // 버튼 텍스트 변경
                    button6.Text = "자동운전";  // "자동 운전"으로 텍스트 변경
                }

                // 실린더 모두 후진
                Writedata[0] |= 0x02; // A 후진
                Writedata[0] &= unchecked((byte)~0x01); // A+ 신호 제거
                Writedata[0] |= 0x08; // B 후진
                Writedata[0] &= unchecked((byte)~0x04); // B+ 신호 제거
                CIFX.xChannelWrite(Writedata);

                // UI 초기화
                label5.Text = "00000000";  // 읽기 데이터 초기화
                label6.Text = "00000000";  // 쓰기 데이터 초기화

                // 자동 실행 및 타이머 멈추기
                isSequenceRunning = false;
                isPaused = false;
                timer2.Stop();  // 타이머2 멈추기 (자동 실행 정지)
                timer1.Stop();  // 타이머1 멈추기 (주기적인 상태 갱신 멈추기)
                MessageBox.Show("자동 운전이 정지되었으며 모든 실린더가 후진 상태로 초기화되었습니다.");
            }
        }
       private void timer2_Tick(object sender, EventArgs e)
        {
            if (isPaused) return; // 💡 일시정지면 그냥 아무것도 하지 않음

            if (sequenceCount >= 3)
            {
                timer2.Stop();  // 자동 실행 완료 후 타이머 멈춤
                isSequenceRunning = false;
                MessageBox.Show("3회 자동 실행 완료");
                return;
            }

            switch (stepCounter)
            {
                case 0: // A 전진
                    Writedata[0] |= 0x01;
                    Writedata[0] &= unchecked((byte)~0x02);
                    break;
                case 1: // B 전진
                    Writedata[0] |= 0x04;
                    Writedata[0] &= unchecked((byte)~0x08);
                    break;
                case 2: // A 후진
                    Writedata[0] |= 0x02;
                    Writedata[0] &= unchecked((byte)~0x01);
                    break;
                case 3: // B 후진
                    Writedata[0] |= 0x08;
                    Writedata[0] &= unchecked((byte)~0x04);
                    break;
            }

            CIFX.xChannelWrite(Writedata);

            stepCounter++;

            if (stepCounter > 3)
            {
                stepCounter = 0;
                sequenceCount++;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // 실린더 모두 후진
            Writedata[0] |= 0x02; // A 후진
            Writedata[0] &= unchecked((byte)~0x01); // A+ 신호 제거
            Writedata[0] |= 0x08; // B 후진
            Writedata[0] &= unchecked((byte)~0x04); // B+ 신호 제거
            CIFX.xChannelWrite(Writedata);

            // UI 초기화
            label5.Text = "00000000";  // 읽기 데이터 초기화
            label6.Text = "00000000";  // 쓰기 데이터 초기화

            // 자동 실행 및 타이머 멈추기
            isSequenceRunning = false;
            isPaused = false;
            timer2.Stop();  // 타이머 멈추기

         
        }
    }
}

