﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace 리스트
{
    class Program
    {
        static void Main(string[] args)
        {
            //선언
            string 변수;

            //초기화
            변수 = "초기화";

            //선언과 동시에 초기화
            List<string> 학교 = new List<string>();
            학교.Add("한국");
            학교.Add("폴리텍");
            학교.Add("아산");
            학교.Add("캠퍼스");

            for (int i = 0; i < 학교.Count; i++)
            {
                Console.WriteLine(학교[i]);
            }

            //선언과 동시에 초기화                        
            List<string> 학교2 = new List<string> { "한국", "폴리텍", "아산", "캠퍼스" };

            //정수형 리스트를 선언 
            //정수형 리스트를 초기화
            //정수형 리스트를 선언과 동시에 초기화
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            List<int> 리스트1 = new List<int>();
            

            //Add는 만들어진 리스트에 가장 뒤에 값이 붙는다.            
            리스트1.Add(1);
            리스트1.Add(2);
            리스트1.Add(3);
            Console.WriteLine(리스트1[0]);
            Console.WriteLine(리스트1[1]);
            Console.WriteLine(리스트1[2]);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();



            List<int> 리스트2 = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            for (int i = 0; i < 리스트2.Count; i++)
            {
                Console.WriteLine(리스트2[i]);
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //insert는 해당 위치에 자리를 만들어 값을 집어 넣습니다. 중간에 들어가는 것이므로 리스트 값들이 하나씩 밀리게 됩니다.

         
            리스트1.Insert(1, 3);
            Console.WriteLine(리스트1[1]);
            Console.WriteLine(리스트1.Count);
            for (int i = 0; i < 리스트1.Count; i++)
            {
                Console.WriteLine(리스트1[i]);
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //Remove는 괄호안에 있는 값을 제거해줍니다.
            //리스트에서 가장 먼저 발견되는 값을 제거한다.

            
            리스트1.Remove(3);
            for (int i = 0; i < 리스트1.Count; i++)
            {
                Console.WriteLine(리스트1[i]);
            }
            
            
            
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();



            //RemoveAt
            리스트1.RemoveAt(1);

            Console.WriteLine(string.Join("", 리스트1));
            for (int i = 0; i < 리스트1.Count; i++)
            {
            
            }

            List<int> 리스트3 = new List<int>();
            리스트3.Add(1);
            리스트3.Add(2);
            리스트3.Add(3);
            리스트3.Add(4);
            리스트3.Add(5);
            리스트3.Add(6);
            리스트3.Add(7);
            리스트3.Add(8);
            리스트3.Add(9);
            리스트3.Add(10);

            리스트3.Sort();
            리스트3.Reverse();
            Console.WriteLine();
            Console.WriteLine(string.Join("    ", 리스트3));
            Console.WriteLine(리스트3.IndexOf(3));


            리스트3.Clear();

            Console.WriteLine(리스트3.Count);


            List<int> 리스트4 = new List<int>();
            리스트4.Add(1);
            리스트4.Add(2);
            리스트4.Add(3);
            리스트4.Add(4);
            리스트4.Add(5);
            리스트4.Add(6);
            리스트4.Add(7);
            리스트4.Add(8);
            리스트4.Add(9);
            리스트4.Add(10);

            리스트4.ForEach(x => Console.WriteLine(x));

            //복습
            //add(값), insert(위치,값),Remove(값), Remove(위치), IndexOf(값)
            //1. List정수형으로 만들고 값을 추가해보도록 합니다. 값은 1,2,3
            //2. 요소들을 가지고 사칙연산을 해봅시다. 결과값은 $"{변수[위치]}+{변수[위치]}={변수[위치]+변수[위치]}"
            //3. 요소들에 새롭게 값을 삽입하고 값은 10,20,30을 넣어봅시다. 위치는 자유롭게
            //4. 반복문을 통해 요소들을 확인해 봅시다. 변수.Count 사용
            //5. 조건문을 사용해서 리스트 값이 5개 이하면 "더 추가해주세요", 10개 이하면"충분합니다." 나머지는 "리스트완성"


            List<int> 복습 = new List<int>();
            복습.Add(1);
            복습.Add(2);
            복습.Add(3);

            Console.WriteLine($"{복습[1]} + {복습[2]} = {복습[1] + 복습[2]}");
            Console.WriteLine($"{복습[1]} - {복습[2]} = {복습[1] - 복습[2]}");
            Console.WriteLine($"{복습[1]} X {복습[2]} = {복습[1] * 복습[2]}");
            Console.WriteLine($"{복습[1]} / {복습[2]} = {복습[1] / 복습[2]}");

            복습.Insert(1, 10);
            복습.Insert(3, 20);
            복습.Insert(5, 30);

            //복습.ForEach(x => Console.WriteLine(x));

            for (int i = 0; i < 복습.Count; i++)
            {
                Console.WriteLine(복습[i]);
            }
            if(복습.Count <= 5)
            {
                Console.WriteLine("더 추가해 주세요");
            }
            else if(복습.Count <= 10)
            {
                Console.WriteLine("충분합니다.");
            }
            else
            {
                Console.WriteLine("리스트 완성");
            }

            //string.join() 중간중간 띄어쓰기나 별표넣기
            //string.concat() 문자열을 결합해줌
            //append문자를 합쳐줌 appendline 문자를 합친후 한줄 내림
            //contain(값) 값이 포함되어 있는지 확인
            if (복습.Contains(10))
            {
                Console.WriteLine($"10이라는 값은 {복습.IndexOf(10)}에 위치하고 있습니다.");
            }
            else
            {
                Console.WriteLine($"10이라는 값이 없습니다.");
            }
          
            Console.WriteLine(복습.Contains(10));
        }
    }
}