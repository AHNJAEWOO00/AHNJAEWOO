﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace MAEGAEBYEONSOO
{
    
    public class MathOperator
    {
        public int multiple(int int_input1, int int_input2)
        {
            return int_input1 * int_input2;
        }
        //11-2 곱하기 함수를 만듭니다. 반환형은 실수, 매개변수도 실수
        public double multiple(double dou_input1, double dou_input2)
        {
            return dou_input1 * dou_input2;
        }
        //11-3 곱하기 함수를 만듭니다. 반환형은 정수, 개수 추가
        public int multiple(int int_input1, int int_input2, int int_input3)
        {
            return int_input1 * int_input2 * int_input3;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            void sayHello(string name="선생")
            {
                Console.WriteLine($"안녕하세요.{name}님");
            }
            sayHello();//기본값이 할당되었기 때문에 매개변수 안넣어도 됨
            sayHello("안재우");//기본값 대신에 매개변수로 작용
                            
            // 7. 매개변수가 여러개일때 기본값이 몇개만 을경우
                            
            //기본값이 적용되는 매개변수는 항상 맨 마지막에 와야함
            
            void subject(string sub1, string sub2, string sub3 = "C#")
            {
                Console.WriteLine($"{sub1},{sub2},{sub3}");
            }
            subject("PLC", "파이썬","캐드");

            // 8. ref 키워드 (값을 참조로 전달)
            void DoubleNumber(ref int num)
            {
                num *= 2;
            }
            void DoubleNumber2(int num)
            {
                num *= 2;
            }
            
            
            int value = 10;
            int value2 = 10;

            DoubleNumber(ref value);
            Console.WriteLine(value);
            

            DoubleNumber2(value2);
            Console.WriteLine(value2);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //out 키워드 여러개 반환값 전달.
            //return, 반환은 자료형을 따라가지만 추가적으로 다른 자료형, 여러개 자료형이 여러개 반환 되어야 할 때 사용.
            void divide(int aa, int bb, out int result1, out int result2)
            {
                result1 = aa / bb;
                result2 = aa % bb;
            }


            int cc, dd;
            divide(10, 2 , out cc , out dd);
            Console.WriteLine($"{cc},{dd}");
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("키", "밸류");


           void printNumber(params int[] numbers)
            {
                foreach (var num in numbers)
                {
                    Console.Write(num + " ");
                }   
                Console.WriteLine();
            }


            printNumber(1, 2, 3, 4, 5, 6, 7, 8, 9);
            int[] int_arr = { 1, 2, 3, 4, 5, 6 };
            printNumber(int_arr);


            //11 메서드 오버로딩 (method overloading)
            //같은 이름의 함수이고 매개변수 타입이나 개수를 다르게 하여 여러개 정의

            //11-1 곱하기 함수를 만듭니다. 반환형은 정수, 매개변수도 정수



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();



            MathOperator math = new MathOperator();
            Console.WriteLine(math.multiple(2, 3));//매개변수 정수 두개;
            Console.WriteLine(math.multiple(2.53, 3.135));//매개변수 실수 두개
            Console.WriteLine(math.multiple(2,3,7));//매개변수 정수 세개
            


            //12 지역변수 vs 전역변수
            //지역변수 = 메서드 내부에서만 사용
            //전역변수 = 클래스 내에서 선언 모든 메서드에서 사용가능
            int count = 0;
            void increase()
            {
                int step = 1;
                count += step;
            }

            
            count = 3;
            increase();
            
            
            //13 재귀 함수
            //함수가 자기를 부른다 본인이 본인을 부르는 함수
            int factorial(int x)
            {
                if (x == 1)
                { 
                    return 1; 
                }
                return x * factorial(x - 1);
            }
            Console.WriteLine(factorial(10));




            //1.반환형 없고 매개변수 없는 함수 만들기
            //2.기본값이 여러개인 함수를 만들기(매개변수가 N개면 기본값이 있는 매개변수는 n-1개로 만들기
            //3.ref.를 쓰는 매개변수 out 하나씩 넣기
            //4.params 가변인자 넣기

            void no_method()
            {
                Console.WriteLine("HELLO WORLD");
            }
            no_method();


            void manymany(string str1, string str2 = "많이", string str3 = "더 많이", string str4 = "진짜 많이", string str5 = "아주많이")
            {
                Console.WriteLine($"{str1},{str2},{str3},{str4},{str5}");    
            }
            manymany("조금");


            void double_event(ref int energy, out int bar)
            {
                energy *= 2;
                bar = energy;
            }
            int duplicate = 9999;


            double_event(ref duplicate, out int end);
            Console.WriteLine(duplicate);
            Console.WriteLine(end);
            
            void train(params string[] strings)
            {
                foreach (string s in strings) Console.WriteLine(s);
            }
            string[] grade = { "1호차", "2호차", "3호차", "4호차", "5호차", };
            train(grade);

           
        }
    }
}
