﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_list
{
    class Program
    {
 

        static void Main(string[] args)
        {
            //문자열 자료형 리스트 만들기
            List<string> list = new List<string>();
            //모든 자료형 리스트 만들기
            
            List<object> list2 = new List<object>();
            list2.Add(1);
            list2.Add(2);
            list2.Add(3);
            list2.Add("a");
            list2.Add("b");
            list2.Add("c");

            List<object> list3 = new List<object>
            { "a","b","c",1,2,3};

            Console.WriteLine(list.GetType());
            Console.WriteLine(list2.GetType());
            List<dynamic> list4 = new List<dynamic>();
            list4.Add(1);
            list4.Add(2);   
            list4.Add(3);   
            list4.Add(4);   
            list4.Add("a");
            list4.Add("b");
            list4.Add("c");
            list4.Add("d");
            Console.WriteLine(list4);
            
            List<object> list5 = new List<object>
            {
            "a","B","C",1,2,3, new List<object>{"d","e","f"}
            };
            //object형으로 list 선언
            //dynamic형으로 list 선언과 초기화
            //이중리스트 자료형은 자유

            List<object> ListA = new List<object>();
            List<dynamic> ListB = new List<dynamic>
            { "a","b","c",1,2,3};
            List<dynamic> ListC = new List<Object>
            {
                "a","b","c",new List<dynamic>{"d","e","f"}
            };
            Console.WriteLine(ListC[3][1]);

            List<dynamic> ListD = new List<dynamic>()
            {
                "a","b","c",new List<string>{"d","e","f"}
            };

            Console.WriteLine(ListD[3][0]);

            // 바깥 리스트 List<object>
            // 안쪽 리스트 List<int>

            List<object> ListE = new List<object>
            {
                "a","b","c",new List<int>{1,2,3}
            };

            Console.WriteLine(ListE[0]);
            List<int> intlist = (List<int>)ListE[3];
            
            
            
            
            
            Console.WriteLine(intlist[0]);
            Console.WriteLine(intlist[1]);
            Console.WriteLine(intlist[2]);


            List<object> ListF = new List<object>
            {
                1,2,3, new List<string>{"a","b","c"}
            };

            Console.WriteLine(((List<string>)ListF[3])[0]);


            //이중리스트
            //object > List<object>{new List<자료형>}-> new List<자료형> object

            //1.이중 리스트를 만들고 내부리스트는 자료형 string으로 만들어봅시다.
            //2.내부 리스트를 받을 수 있는 새로운 List를 만들고 변수에 담아줍시다.
            //3.새로 담긴 리스트를 인덱스를 사용하여 요소 접근을 해봅시다.
            //4.리스트의 모든 요소를 출력 해 봅시다.

            //이중 리스트 만들기
            List<object> subject = new List<object>
            {
                1,2,3,new List<string>{"1교시","2교시","3교시"}
            };


            //변수 times에 내부리스트 목록을 넣고 그 중 0번인덱스 값을 출력함
            List<string> times = (List<string>)subject[3];
            
            Console.Write(times[0]);
            Console.Write(times[1]);
            Console.WriteLine(times[2]);




            foreach (string s in times)
            {
                Console.Write(s+" ");
            }
            Console.WriteLine(string.Join("     ", times));
        }
    }
}
