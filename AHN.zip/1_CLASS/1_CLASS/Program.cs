﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace _1_CLASS
{

    class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person("안모씨", 90);
            Person p2 = new Person("김모씨", 60);
            p1.introduce();
            p2.introduce();

            Car c1 = new Car("테슬라", 2023);
            Car c2 = new Car("고철덩어리", 1820);
            c1.Make();
            c2.Make();

            Animal a1 = new Animal("기린", "아프리카");
            Animal a2 = new Animal("아프리카 코끼리", "인도");
            Animal a3 = new Animal("고양이", "이집트");

            a1.Animal2();
            a2.Animal2();
            a3.Animal2();

            Employee ee = new Employee();
            ee.Salary = -1000000;
            

            Person2 p3 = new Person2();
            p3.Name = "미스터안";
            p3.Age = 25;


            Employee ee3 = new Employee();
            ee3.File = "결재서류";
            Console.WriteLine(ee3.File);
            ee3.File = "양서류";
            Console.WriteLine(ee3.File);

            Bank bk = new Bank();
            bk.Account = 10000;
            bk.Deposit(5000);
            bk.Withdraw(20000);
        }
    }
}
