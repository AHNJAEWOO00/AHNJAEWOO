﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_CLASS
{
    class Bank
    {
        private int account;
        public void Deposit(int money)
        {
            if (money > 0)
            {
                account += money;
                Console.WriteLine($"현재{money}원이 입금되어서 잔고에 {account}원이 있습니다.");
            }
            else if ( money == 0 )
            {
                Console.WriteLine("돈 가져 오세요");
            }
            else
            {
                Console.WriteLine("적자입니다.");
            }
        }
        public void Withdraw(int money)
        {
            if (money > 0 && account >= money)
            {
                account -= money;
                Console.WriteLine($"현재 {money}원이 출금되어서 잔고에 {account}원이 있습니다.");
            }
            else if (money > 0 && account < money)
            {
                Console.WriteLine("잔고가 부족합니다.");
            }
            else
            {
                Console.WriteLine("돈 가져 오세요");
            }
        }
        public int Account
        {
            get { return account; } // 읽기
            set
            {
                if (value == 0)
                {
                    account = 1;
                }
                else
                {
                    account = value;
                }
            } 
        }

    }
}
  
    class Person2
    {
        // 1. private 변수
        private string name;
        private int age;

        // 2. public 속성 (get / set)
        public string Name
        {
            get { return name; }   // 값 읽기
            set { name = value; }  // 값 넣기
        }

        public int Age
        {
            get { return age; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("나이는 0 이상이어야 해요!");
                }
                else
                {
                    age = value;
                }
            }
        }
    }


    class Person//클래스명
    {
        // 필드(변수)//해당 클래스에서만 쓰는 변수
        public string Name;
        public int Age;
        public Person(string name, int age)//생성자 기본형 public 클래스명
        {
            Name = name;
            Age = age;
        }
        //메서드
        public void introduce()
        {
            Console.WriteLine($"안녕하세요, 제 이름은 {Name}이고, 나이는 {Age}세 입니다.");
        }
    }
    class Car
    {
        public string Name;
        public int Year;
        public Car(string name, int year)
        {
            Name = name;
            Year = year;
        }
        public void Make()
        {
            Console.WriteLine($"안녕하세요, 제 차는 {Name}이고, 연식은 {Year}입니다.");
        }
    }
    class Animal
    {
        public string Name;
        public string Place;
        public Animal(string name, string place)
        {
            Name = name;
            Place = place;
        }
        public void Animal2()
        {
            Console.WriteLine($"안녕하세요, 저는 {Name}이고, {Place}에 살고 있습니다.");
        }
    }
    class Employee
    {
        private int salary;
        private string file;
        public string File
        {
            get { return file; } // 읽기
            set
            {
                if (value == "결재서류")
                {
                    file = "승인";
                }
                else
                { file = value; }
            } // 쓰기
        }
        public int Salary
        {
            get { return salary; }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("저는 일 못합니다.");
                }
                else
                {
                    salary = value;
                }
            }
        }
    }
    class ABC
    {

    }

