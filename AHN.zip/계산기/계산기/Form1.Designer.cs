﻿namespace 계산기
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.equal = new System.Windows.Forms.Button();
            this.dot = new System.Windows.Forms.Button();
            this.no0 = new System.Windows.Forms.Button();
            this.plusminus = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.no3 = new System.Windows.Forms.Button();
            this.no2 = new System.Windows.Forms.Button();
            this.no1 = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.no6 = new System.Windows.Forms.Button();
            this.no5 = new System.Windows.Forms.Button();
            this.no4 = new System.Windows.Forms.Button();
            this.times = new System.Windows.Forms.Button();
            this.no9 = new System.Windows.Forms.Button();
            this.no8 = new System.Windows.Forms.Button();
            this.no7 = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.lootx = new System.Windows.Forms.Button();
            this.xdouble = new System.Windows.Forms.Button();
            this.divx = new System.Windows.Forms.Button();
            this.del = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.CE = new System.Windows.Forms.Button();
            this.percent = new System.Windows.Forms.Button();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.lbl_memory = new System.Windows.Forms.Label();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.46875F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.53125F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.equal, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.dot, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.no0, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.plusminus, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.plus, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.no3, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.no2, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.no1, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.minus, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.no6, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.no5, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.no4, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.times, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.no9, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.no8, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.no7, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.div, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.lootx, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.xdouble, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.divx, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.del, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.C, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.CE, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.percent, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(16, 245);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 126F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 154F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 136F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1280, 779);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // equal
            // 
            this.equal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.equal.Location = new System.Drawing.Point(963, 646);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(314, 130);
            this.equal.TabIndex = 23;
            this.equal.Text = "=";
            this.equal.UseVisualStyleBackColor = true;
            this.equal.Click += new System.EventHandler(this.btn_equal_Click);
            // 
            // dot
            // 
            this.dot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dot.Location = new System.Drawing.Point(649, 646);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(308, 130);
            this.dot.TabIndex = 22;
            this.dot.Text = ".";
            this.dot.UseVisualStyleBackColor = true;
            this.dot.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no0
            // 
            this.no0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no0.Location = new System.Drawing.Point(323, 646);
            this.no0.Name = "no0";
            this.no0.Size = new System.Drawing.Size(320, 130);
            this.no0.TabIndex = 21;
            this.no0.Text = "0";
            this.no0.UseVisualStyleBackColor = true;
            this.no0.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // plusminus
            // 
            this.plusminus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plusminus.Location = new System.Drawing.Point(3, 646);
            this.plusminus.Name = "plusminus";
            this.plusminus.Size = new System.Drawing.Size(314, 130);
            this.plusminus.TabIndex = 20;
            this.plusminus.Text = "士";
            this.plusminus.UseVisualStyleBackColor = true;
            // 
            // plus
            // 
            this.plus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plus.Location = new System.Drawing.Point(963, 521);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(314, 119);
            this.plus.TabIndex = 19;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.btn_Operator_Click);
            // 
            // no3
            // 
            this.no3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no3.Location = new System.Drawing.Point(649, 521);
            this.no3.Name = "no3";
            this.no3.Size = new System.Drawing.Size(308, 119);
            this.no3.TabIndex = 18;
            this.no3.Text = "3";
            this.no3.UseVisualStyleBackColor = true;
            this.no3.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no2
            // 
            this.no2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no2.Location = new System.Drawing.Point(323, 521);
            this.no2.Name = "no2";
            this.no2.Size = new System.Drawing.Size(320, 119);
            this.no2.TabIndex = 17;
            this.no2.Text = "2";
            this.no2.UseVisualStyleBackColor = true;
            this.no2.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no1
            // 
            this.no1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no1.Location = new System.Drawing.Point(3, 521);
            this.no1.Name = "no1";
            this.no1.Size = new System.Drawing.Size(314, 119);
            this.no1.TabIndex = 16;
            this.no1.Text = "1";
            this.no1.UseVisualStyleBackColor = true;
            this.no1.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // minus
            // 
            this.minus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.minus.Location = new System.Drawing.Point(963, 367);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(314, 148);
            this.minus.TabIndex = 15;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.btn_Operator_Click);
            // 
            // no6
            // 
            this.no6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no6.Location = new System.Drawing.Point(649, 367);
            this.no6.Name = "no6";
            this.no6.Size = new System.Drawing.Size(308, 148);
            this.no6.TabIndex = 14;
            this.no6.Text = "6";
            this.no6.UseVisualStyleBackColor = true;
            this.no6.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no5
            // 
            this.no5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no5.Location = new System.Drawing.Point(323, 367);
            this.no5.Name = "no5";
            this.no5.Size = new System.Drawing.Size(320, 148);
            this.no5.TabIndex = 13;
            this.no5.Text = "5";
            this.no5.UseVisualStyleBackColor = true;
            this.no5.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no4
            // 
            this.no4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no4.Location = new System.Drawing.Point(3, 367);
            this.no4.Name = "no4";
            this.no4.Size = new System.Drawing.Size(314, 148);
            this.no4.TabIndex = 12;
            this.no4.Text = "4";
            this.no4.UseVisualStyleBackColor = true;
            this.no4.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // times
            // 
            this.times.Dock = System.Windows.Forms.DockStyle.Fill;
            this.times.Location = new System.Drawing.Point(963, 241);
            this.times.Name = "times";
            this.times.Size = new System.Drawing.Size(314, 120);
            this.times.TabIndex = 11;
            this.times.Text = "X";
            this.times.UseVisualStyleBackColor = true;
            this.times.Click += new System.EventHandler(this.btn_Operator_Click);
            // 
            // no9
            // 
            this.no9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no9.Location = new System.Drawing.Point(649, 241);
            this.no9.Name = "no9";
            this.no9.Size = new System.Drawing.Size(308, 120);
            this.no9.TabIndex = 10;
            this.no9.Text = "9";
            this.no9.UseVisualStyleBackColor = true;
            this.no9.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no8
            // 
            this.no8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no8.Location = new System.Drawing.Point(323, 241);
            this.no8.Name = "no8";
            this.no8.Size = new System.Drawing.Size(320, 120);
            this.no8.TabIndex = 9;
            this.no8.Text = "8";
            this.no8.UseVisualStyleBackColor = true;
            this.no8.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // no7
            // 
            this.no7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.no7.Location = new System.Drawing.Point(3, 241);
            this.no7.Name = "no7";
            this.no7.Size = new System.Drawing.Size(314, 120);
            this.no7.TabIndex = 8;
            this.no7.Text = "7";
            this.no7.UseVisualStyleBackColor = true;
            this.no7.Click += new System.EventHandler(this.btnnumber_Click);
            // 
            // div
            // 
            this.div.Dock = System.Windows.Forms.DockStyle.Fill;
            this.div.Location = new System.Drawing.Point(963, 122);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(314, 113);
            this.div.TabIndex = 7;
            this.div.Text = "÷";
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.btn_Operator_Click);
            // 
            // lootx
            // 
            this.lootx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lootx.Location = new System.Drawing.Point(649, 122);
            this.lootx.Name = "lootx";
            this.lootx.Size = new System.Drawing.Size(308, 113);
            this.lootx.TabIndex = 6;
            this.lootx.Text = "2√x";
            this.lootx.UseVisualStyleBackColor = true;
            // 
            // xdouble
            // 
            this.xdouble.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xdouble.Location = new System.Drawing.Point(323, 122);
            this.xdouble.Name = "xdouble";
            this.xdouble.Size = new System.Drawing.Size(320, 113);
            this.xdouble.TabIndex = 5;
            this.xdouble.Text = "X^2";
            this.xdouble.UseVisualStyleBackColor = true;
            // 
            // divx
            // 
            this.divx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.divx.Location = new System.Drawing.Point(3, 122);
            this.divx.Name = "divx";
            this.divx.Size = new System.Drawing.Size(314, 113);
            this.divx.TabIndex = 4;
            this.divx.Text = "1/x";
            this.divx.UseVisualStyleBackColor = true;
            // 
            // del
            // 
            this.del.Dock = System.Windows.Forms.DockStyle.Fill;
            this.del.Location = new System.Drawing.Point(963, 3);
            this.del.Name = "del";
            this.del.Size = new System.Drawing.Size(314, 113);
            this.del.TabIndex = 3;
            this.del.Text = "Del";
            this.del.UseVisualStyleBackColor = true;
            this.del.Click += new System.EventHandler(this.del_Click);
            // 
            // C
            // 
            this.C.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C.Location = new System.Drawing.Point(649, 3);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(308, 113);
            this.C.TabIndex = 2;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = true;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // CE
            // 
            this.CE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CE.Location = new System.Drawing.Point(323, 3);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(320, 113);
            this.CE.TabIndex = 1;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = true;
            // 
            // percent
            // 
            this.percent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.percent.Location = new System.Drawing.Point(3, 3);
            this.percent.Name = "percent";
            this.percent.Size = new System.Drawing.Size(314, 113);
            this.percent.TabIndex = 0;
            this.percent.Text = "%";
            this.percent.UseVisualStyleBackColor = true;
            // 
            // txt_result
            // 
            this.txt_result.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_result.Location = new System.Drawing.Point(13, 126);
            this.txt_result.Name = "txt_result";
            this.txt_result.Size = new System.Drawing.Size(1280, 63);
            this.txt_result.TabIndex = 5;
            this.txt_result.Text = "0";
            this.txt_result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_result.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_result_KeyPress);
            // 
            // lbl_memory
            // 
            this.lbl_memory.Font = new System.Drawing.Font("굴림", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_memory.Location = new System.Drawing.Point(16, 13);
            this.lbl_memory.Name = "lbl_memory";
            this.lbl_memory.Size = new System.Drawing.Size(1277, 110);
            this.lbl_memory.TabIndex = 6;
            this.lbl_memory.Text = "0";
            this.lbl_memory.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 1051);
            this.Controls.Add(this.lbl_memory);
            this.Controls.Add(this.txt_result);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox txt_result;
        private System.Windows.Forms.Label lbl_memory;
        private System.Windows.Forms.Button equal;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button no0;
        private System.Windows.Forms.Button plusminus;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button no3;
        private System.Windows.Forms.Button no2;
        private System.Windows.Forms.Button no1;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button no6;
        private System.Windows.Forms.Button no5;
        private System.Windows.Forms.Button no4;
        private System.Windows.Forms.Button times;
        private System.Windows.Forms.Button no9;
        private System.Windows.Forms.Button no8;
        private System.Windows.Forms.Button no7;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Button lootx;
        private System.Windows.Forms.Button xdouble;
        private System.Windows.Forms.Button divx;
        private System.Windows.Forms.Button del;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button percent;
    }
}

