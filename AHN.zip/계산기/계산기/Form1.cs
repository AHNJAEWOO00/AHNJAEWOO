﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 계산기
{
    public partial class Form1: Form
    {

        //전역변수들
        string input = string.Empty; //입력값
        string num1 = string.Empty;//첫번째 숫자
        string num2 = string.Empty;//두번째 숫자
        char operation; //연산자
        double result = 0;// 결과값
       
        public Form1()
        {
            InitializeComponent();
            lbl_memory.Visible = false; //메모리 레이블 숨김
        }

        //함수 여기부터
        private void Updatememory()
        {
            lbl_memory.Visible = true;
            lbl_memory.Text = num1+"" + operation + " " + input; //메모리 레이블 업데이트
        }

        //함수 여기까지
        private void btnnumber_Click(object sender, EventArgs e)
        {
            if(txt_result.Text.Contains(".")&&((Button)sender).Text == ".")
            {return;}
            else
            {
                input += ((Button)sender).Text;
            }
            txt_result.Text = input;
            Updatememory();
            txt_result.Focus();
        }

       

        private void btn_Operator_Click(object sender, EventArgs e)
        {
            num1 = input;
            operation = Convert.ToChar(((Button)sender).Text);//
            input = string.Empty;

            lbl_memory.Visible = true;
            Updatememory();
            txt_result.Focus();
        }
        private void btn_equal_Click(object sender, EventArgs e)
        {
            num2 = input;
            double check1, check2;
            double.TryParse(num1, out check1);
            double.TryParse(num2, out check2);

            switch(operation)
            {
                case '+':
                    result  = check1 + check2;
                    break;
                case '-':
                    result = check1 - check2;
                    break;
                case 'X':
                    result = check1 * check2;
                    break;
                case '÷':
                    if (check2 == 0)
                    {
                        MessageBox.Show("0으로 나눌 수 없습니다.");
                        return;
                    }
                    result = check1 / check2;
                    break;
            }
            txt_result.Text = result.ToString();
        }

        private void txt_result_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || (e.KeyChar == '.' && !input.Contains('.')))
            {
                input += e.KeyChar;
                txt_result.Text = input;
                Updatememory();
            }
            else 
            {
                e.Handled = true; // 숫자와 '.' 이외의 키 입력을 무시
            }
        }

        private void C_Click(object sender, EventArgs e)
        {
            num1 = num2 = input = string.Empty; //입력값 초기화
            txt_result.Text = "0"; //결과값 초기화    
            lbl_memory.Text = "";
            lbl_memory.Visible = false; //메모리 레이블 숨김
            txt_result.Focus(); //포커스
        }

        private void del_Click(object sender, EventArgs e)
        {
            if (input.Length > 0)
            {
                input = input.Substring(0, input.Length - 1); //입력값에서 마지막 문자 제거
                txt_result.Text = input.Length > 0 ? input:"0"; //결과값 업데이트
                //메모리 레이블 업데이트
                Updatememory();
            }
            txt_result.Focus();
        }

        // 나머지 버튼은 숙제로 GO

    }
}
