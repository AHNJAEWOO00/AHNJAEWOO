﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program
{
    class Program
    {
        static void Main(string[] args)
        {
            //암시적 형변환 (작은 데이터형 -> 큰 데이터형)
            //int > long
            int small = 123;
            long big;
            big = small;

            Console.WriteLine(big);

            
            //int > double
            double large;
            large = small;
            Console.WriteLine(large);

            //명시적 형변환(큰 데이터형 -> 작은 데이터형)
            //double > int
            double bigbig = 3.14;
            int smallsmall;
            smallsmall = (int)bigbig;
            Console.WriteLine(smallsmall);

            //컨버터.을 누르면 다양한 자료형을 변환가능
            //스트링> int
            //구분하는 방법 = 변환값에 사칙연산을 해본다
            
            string num = "123";
            int pos;
            pos = Convert.ToInt32(num);
            Console.WriteLine(pos);
            Console.WriteLine(num);
            Console.WriteLine(pos + 1);
            Console.WriteLine(num + 1);

            //PARSE Tryparse
            string pi = "3.141592";
            double pi2 = double.Parse(pi);
            bool trfa;
            trfa = double.TryParse(pi, out double pi3);
            Console.WriteLine(pi+1);
            Console.WriteLine(pi2+1);
            Console.WriteLine(trfa);
            Console.WriteLine(pi3 + 1);
            //파스 오류 형태 / 선언한 자료형과 변환하는 자료형이 다를때  오류가 발생
            //트라이파스 / 오류 형태 / false값을 반환 0가 뜸 / 프로그램 에러가 없음 true 또는 false값을 반환





        }
    }
}
