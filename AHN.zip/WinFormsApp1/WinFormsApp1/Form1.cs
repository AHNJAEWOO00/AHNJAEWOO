using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        byte[] writedata = new byte[8];
        byte[] readdata = new byte[34];
      public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//�����ư
        {
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label3.Text = "���󿬰�";
                label3.ForeColor = Color.Green;
            }
            else
            {
                label3.Text = "����ȵ�";
                label3.ForeColor = Color.Red;
            }
        }
    }
}
