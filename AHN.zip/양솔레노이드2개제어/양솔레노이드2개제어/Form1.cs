﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;


namespace 양솔레노이드2개제어
{
    public partial class Form1: Form
    {


        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        int Auto = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.Blue;
                timer1.Interval = 300;
                timer1.Start();
                button1_Click(null, null);
            }
            else
            {
                label3.Text = "NG";
                label3.ForeColor = Color.Red;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label3.Text == "OK")
            {
                Readdata = CIFX.xChannelRead();
                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                label5.Text = ReadDataConv;
                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                label6.Text = WritedataConv;
                label5.Text = ReadDataConv[6] == '1' ? "전진" : "후진";
                label7.Text = ReadDataConv[4] == '1' ? "전진" : "후진";
            }

            }
    }
}
