import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QPushButton, QVBoxLayout, QLabel


class MyApp(QMainWindow):
    def __init__(self):
        super().__init__()
        # self.innit()
        uic.loadUi("button3.ui", self)

        self.btn_1.clicked.connect(self.button_click_1)
        self.btn_2.clicked.connect(self.button_click_2)
        self.btn_3.clicked.connect(self.button_click_3)
        #객체의 변수
        self.click_count = 0
        self.nametag_1 = "네임태그"
        self.nametag_2 = "네임태그라고!"
        self.nametag_3 = "네임태그란 말입니다."

    def button_click_1(self):
        #객체의 변수 증가하기
        self.click_count += 1

        self.btn_1.setText(f"{self.nametag_1}..")
    def button_click_2(self):
        #객체의 변수 증가하기
        self.click_count += 1

        self.btn_2.setText(f"{self.nametag_2}..")
    def button_click_3(self):
        #객체의 변수 증가하기
        self.click_count += 1

        self.btn_3.setText(f"{self.nametag_3}..")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())