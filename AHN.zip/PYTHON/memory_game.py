from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton,QMainWindow
from PyQt5.QtCore import QTimer
import sys
import random

class Memory_Game(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("memory_game.ui", self)

        # 카드 내용 - 짝이 맞는 쌍 8개 (총 16개)
        self.card_values = list("AABBCCDDEEFFGGHH")
        random.shuffle(self.card_values)

        # 버튼들 모으기
        self.buttons = []
        for i in range(1, 17):  # 1~16
            btn = getattr(self, f"QPushButton{i}")
            btn.clicked.connect(self.make_click_handler(btn, i-1))
            self.buttons.append(btn)

        self.revealed = []  # [(index, value), ...]
        self.locked = [False]*16  # 고정된 카드인지

        self.label.setText("시도 횟수: 0")
        self.tries = 0

        # 게임 시작 버튼이 있다면 (옵션)
        if hasattr(self, 'QPushButton'):
            self.QPushButton.clicked.connect(self.restart_game)

    def make_click_handler(self, btn, idx):
        def handler():
            if self.locked[idx] or len(self.revealed) == 2:
                return

            btn.setText(self.card_values[idx])
            self.revealed.append((idx, self.card_values[idx]))

            if len(self.revealed) == 2:
                QTimer.singleShot(500, self.check_match)

        return handler

    def check_match(self):
        idx1, val1 = self.revealed[0]
        idx2, val2 = self.revealed[1]

        self.tries += 1
        self.label.setText(f"시도 횟수: {self.tries}")

        if val1 == val2:
            self.locked[idx1] = True
            self.locked[idx2] = True
        else:
            self.buttons[idx1].setText("")
            self.buttons[idx2].setText("")

        self.revealed = []

        if all(self.locked):
            self.label.setText(f"🎉 성공! 총 시도: {self.tries}")

    def restart_game(self):
        self.card_values = list("AABBCCDDEEFFGGHH")
        random.shuffle(self.card_values)
        self.revealed = []
        self.locked = [False]*16
        self.tries = 0
        self.label.setText("시도 횟수: 0")
        for btn in self.buttons:
            btn.setText("")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    game = Memory_Game()
    game.show()
    sys.exit(app.exec_())