import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QPushButton, QVBoxLayout, QLabel
from PyQt5 import uic


class MyApp(QMainWindow):
    def __init__(self):
        super().__init__()
        # self.innit()
        uic.loadUi("button.ui", self)



        #self는 myapp을 이용해 만든 객체
        #pushButton은 프로그램 안에서 만들어진 버튼 이름
        #clicked 버튼이 클릭될 때 
        #connect() 이벤트 연결    
        self.pushButton.clicked.connect(self.button_click)
        #객체의 변수
        self.click_count = 0
    
    
    def button_click(self):
        #객체의 변수 증가하기
        self.click_count += 1
        self.pushButton.setText(f"{self.click_count}번 클릭 했습니다.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())