﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace 조건문1
{
    class Program
    {
        static void Main(string[] args)
        {
            int 나이 = 20;
            
            if (나이 > 20)
            {
                Console.WriteLine("성인입니다.");
            }
            
            else if (나이 == 20)
            {
                Console.WriteLine("스무살입니다.");
            }    
            
            else
            {
                Console.WriteLine("스무살이 아닙니다.");
            }



            //점수 85점을 초기화
            //점수 90이상 A 80이상 B 70이상은 C 나머지 D

            int 점수 = 85;
            if(점수>=90)
            {
                Console.WriteLine("A학점");
            }
            else if (점수 >= 80)
            {  
                Console.WriteLine("B학점");
            }
            else if (점수 >= 70)
            {
                Console.WriteLine("C학점");
            }
            else
            {
                Console.WriteLine("D학점");
            }

        }
    }
}
