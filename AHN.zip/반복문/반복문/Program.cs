﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace 반복문
{
    class Program
    {
        static void Main(string[] args)
        {
            //1번 int i=0 ; 몇번 실행할것인가를 담는 그릇
            //2번 i < 3; 몇번을 실행할지 조건을 걸어줌
            //3번 i++를 통해 반복 차수를 늘려줌



            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine($"현재 숫자 : {i}");
            }
            //console.WhriteLene(i)를 for문 밖에서 사용하면  i값을 찾을 수 없다고 나온다.

            //I++의 내용은 기존에 있던 i값에 1을 더해주는 뜻이다.
            //즉 i = i + 1과 같은 의미이다.
            //i--는 i값에 1을 빼주는 뜻이다.
            //i = i - 1과 같은 의미이다.
            //i += 2는 i값에 2를 더해주는 뜻이다.
            //i -= 2는 i값에 2를 빼주는 뜻이다.
            //i *= 2는 i값에 2를 곱해주는 뜻이다.
            //i /= 2는 i값에 2를 나눠주는 뜻이다.
            Console.WriteLine();
            Console.WriteLine();


            


            int j = 0;
            //j++;
            //++j;
            //j--;
            //--j;

            //j /= j;
            //j *= j;


            for (j = 0; j < 3; j++)
            {
                Console.WriteLine($"현재 숫자 : {j}");
            }
            Console.WriteLine("현재숫자: "+j);

            for (j = 3; j > 0 ;j--)
            {
                Console.WriteLine(j);
            }
            Console.WriteLine();
            Console.WriteLine();

            
            for (int i = 1; i < 10; i+=2)
            {
                Console.WriteLine(i);   
            }

            Console.WriteLine();
            Console.WriteLine();

                
            for (int i = 10; i > 0; i -= 2)
            {
                Console.WriteLine(i);
            }


        }
    }
}
