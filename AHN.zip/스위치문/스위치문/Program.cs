﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 스위치문
{
    class Program
    {
        static void Main(string[] args)
        {
            string 요일 = "토요일";

            switch (요일)
            {
                case "월요일":
                    Console.WriteLine("월요일입니다.");
                    break;
                case "화요일":
                    Console.WriteLine("화요일입니다."); 
                    break;
                case "수요일":
                    Console.WriteLine("수요일입니다"); 
                    break;
                case "목요일":
                    Console.WriteLine("목요일입니다");
                    break;
                case "금요일":
                    Console.WriteLine("금요일입니다");
                    break;
               default:
                    Console.WriteLine("주말입니다.");
                    break;
            }

            //무지개 초기화는 마음에 드는 색깔
            //case "빨주노초파" 나머지 "남보"

            string 색깔 = "파랑";

            switch(색깔)
            {
                case "빨강":
                    Console.WriteLine("빨강입니다."); break;
                case "주황":
                    Console.WriteLine("주황입니다."); break;
                case "노랑":
                    Console.WriteLine("노랑입니다."); break;
                case "초록":
                    Console.WriteLine("초록입니다."); break;
                case "파랑":
                    Console.WriteLine("파랑입니다."); break;
                case "남색":
                    Console.WriteLine("남색입니다."); break;
                default:
                    Console.WriteLine("보라입니다."); break;
            }    
            // 스위치에서 goto를 쓸 수있다.

        }
    }
}