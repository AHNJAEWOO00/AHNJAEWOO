﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace _4_dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> 사전 = new Dictionary<int, string>();//Key type Int Value Type String


            //초기화
            사전.Add(1, "한국");
            사전.Add(2, "폴리텍");
            사전.Add(3, "아산");
            사전.Add(4, "캠퍼스");

            //선언과 초기화

            foreach (var item in 사전)
            {
                Console.WriteLine(item.Key+":"+item.Value);
            }


            Dictionary<int, string> 초기화 = new Dictionary<int, string>
            {
                {1,"한국"},{2,"폴리텍"},{3,"아산"},{4,"캠퍼스"}
            };

            foreach(var item in 초기화)
            {
                Console.WriteLine(item.Key+":"+item.Value);
            }


            Console.WriteLine(사전[1]);


           
            //변수 .trygetvalue(키, out Tvalue 변수)
            // 키가 있으면 변수에 해당값을 받아옴(true)  없으면 아무것도 못받음(false)
            
            
            if(사전.TryGetValue(3, out string result))
            {
                Console.WriteLine($"결과값 {result}이 있습니다.");
            }
            else
            {
                Console.WriteLine($"결과값 {result}이 없습니다.");
            }
           if(사전.ContainsKey(3))
            {
                Console.WriteLine($"{사전[3]}가 있습니다.");
            }
           else
            {
                Console.WriteLine("키가 없습니다.");
            }
           
            if (사전.ContainsValue("아무거나"))
            {
                Console.WriteLine("아무거나 값이 있습니다.");
            }
            else
            {
                Console.WriteLine("키가 없습니다.");
            }
            사전.Remove(1);
            foreach(var item in 사전)
            {
                Console.WriteLine(item.Key+":"+item.Value);
            }
            
            사전.Clear();
            Console.WriteLine(사전.Count);

            //DICTIONARY STRING,STRING으로 딕셔너리 만들고
            //월,PLC 화 #C 수 시퀀스 목요일 Python 금요일 캐드
            Dictionary<string, string> 학교 = new Dictionary<string, string>
            {
                {"월","PLC"},{"화","C#"},{"수","시퀀스"},{"목","PYTHON"},{"금","AUTO CAD"}
            };
            foreach (var item in 학교)
            {
                Console.WriteLine(item.Key + ":" + item.Value);
            }
            
            
            // add를 통해 새로운 값 추가하기 토,게임 일, 운동_
            //값 지우기
            //if 문으로 키:수가 있으면 "시퀀스 수업합니다" 출력
            //if 문으로 밸류 winform이 있으면 "winform 수업중" 없으면 "winform 수업해주세요" 출력
            //if 문으로 (금, out string result2)



            학교.Add("토","게임");
            학교.Add("일", "운동");
            학교.Remove("화");
            if(학교.ContainsKey("수"))
            {
                Console.WriteLine("시퀀스 수업합니다.");
            }
            if(학교.ContainsValue("winform"))
            {
                Console.WriteLine("윈폼 수업이 있습니다.");
            }
            else
            {
                Console.WriteLine("윈폼 수업해주세요");
            }
            if(학교.TryGetValue("금",out string return2))
            {
               Console.WriteLine($"{return2} 출력");
            }
            else
            {
                Console.WriteLine("수업 없음");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //1.딕셔너리 <double,double>를 만들어서 키, 밸류 3쌍 만들기
            //2.trygetvelue(키,out double 실수)"{키} :{실수}"출력되도록 만들기
            //3.변수.keys, 변수.value를 이용해서 모두 출력하기
            Dictionary<double, double> 딕셔너리 = new Dictionary<double, double>()
            {
                {1,12.3},{2,45.6},{3,78.9}
            };

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();



            if (딕셔너리.TryGetValue(1, out double 실수)) Console.WriteLine($"{1}:{실수}");

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            foreach (var item in 딕셔너리)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine($"키:" + string.Join(",", 딕셔너리.Keys));
            Console.WriteLine($"값:" + string.Join(",", 딕셔너리.Values));

        }
    }
}
