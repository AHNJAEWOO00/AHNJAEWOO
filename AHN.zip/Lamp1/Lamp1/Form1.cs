﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lamp1
{
    public partial class Form1: Form
    {
        int Auto  = 0;
        int Count = 0;
        int A     = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Interval = 100;
            timer1.Start();
            A     = 1;
            Auto  = 0;
            Count = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Interval = 100;
            timer1.Start();
            A     = 2;
            Auto  = 0;
            Count = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button1.Text = "소등";
            label1.Text  = "소등";
            label4.Text  = Count.ToString();
            int Counting = Convert.ToInt32(numericUpDown1.Value);
            
            
            if ((A == 1) || (A == 2 && Count < Counting))
            {
                switch (Auto)
                {
                    case 0:
                        if (button1.BackColor == Color.White)
                        {
                            button1.BackColor = Color.Green;
                            button1.ForeColor = Color.Blue;
                            label1.BackColor  = Color.Pink;
                            label1.ForeColor  = Color.Red;
                            label1.Text  = "점등";
                            button1.Text = "점등";
                            Auto++;

                        }
                        break;
                    case 1:
                        if (button1.BackColor == Color.Green)
                        {
                            button1.BackColor = Color.White;
                            button1.ForeColor = Color.Black;
                            button1.Text = "소등";

                            label1.BackColor  = Color.White;
                            label1.ForeColor  = Color.Black;
                            label1.Text  = "점등";
                            Auto++;
                            Count++;

                        }
                        break;
                    case 2:
                        Auto = 0;
                        break;

                }
            }
            else
            {
                timer1.Stop();
            }
        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Auto  = 0;
            Count = 0;
            A     = 0;
            timer1.Stop();
            label4.Text       = "0";
            button1.BackColor = Color.White;
            button1.ForeColor = Color.Black;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
