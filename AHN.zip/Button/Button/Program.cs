﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // ECC 모듈 읽기/쓰기 버퍼 정의

        byte[] writedata = new byte[8]; // ECC 모듈을 위한 쓰기 버퍼
        byte[] readdata = new byte[34]; // ECC 모듈을 위한 읽기 버퍼
        public Form1()
        {
            InitializeComponent(); // 폼 구성 요소 초기화
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // 폼이 로드될 때 호출되는 메서드
        }
        private void button1_Click(object sender, EventArgs e)//연결
버튼
{
// EtherCAT 마스터에 연결
uint connect = CIFX.DriveConnect();
// 연결이 성공했는지 확인
if (connect != 0)
{
label3.Text = "정상 연결"; // "정상 연결" 메시지 표시
label3.ForeColor = Color.LimeGreen; // 텍스트 색상을

녹색으로 설정
    }
else
{
label3.Text = "연결 안됨"; // "연결 안됨" 메시지 표시
label3.ForeColor = Color.Red; // 텍스트 색상을 빨간색으

로 설정
}
}
private void button2_Click(object sender, EventArgs e)//해제
버튼
{
// EtherCAT 마스터 연결 해제
label3.Text = "해제 됨"; // "해제 됨" 메시지 표시
label3.ForeColor = Color.Red; // 텍스트 색상을 빨간색으로

설정

CIFX.close(); // 연결 닫기

}
private void button3_Click(object sender, EventArgs e)//Lamp
켜기 버튼
{
    // writedata의 첫 번째 비트를 토글하여 램프 켜기
    writedata[0] ^= 0x01;
CIFX.xChannelWrite(writedata); // ECC 모듈에 데이터 쓰기
label4.Text = "Lamp가 점등되었습니다 "; // "Lamp가 점등되

었습니다" 메시지 표시
}
private void button4_Click(object sender, EventArgs e)//Lamp
끄기 버튼
{
    // writedata의 첫 번째 비트를 토글하여 램프 끄기
    writedata[0] ^= 0x01;
CIFX.xChannelWrite(writedata); // ECC 모듈에 데이터 쓰기
label4.Text = "Lamp가 소등되었습니다 "; // "Lamp가 소등되

었습니다" 메시지 표시
}
}
}