﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace 반복문2
{
    class Program
    {
        static void Main(string[] args)
        {
            //for

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"반복문이{i}회 실행되었습니다.");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //반복문을 사용하여 0부터 10까지 1씩 증가하여 숫자를 출력하는 프로그램 만들기
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine($"반복문이{i}회 실행되었습니다.");
            }


            Console.WriteLine();
            Console.WriteLine();


            for (int i = 10; i >= 0; i--)
            {
                Console.WriteLine($"반복문이{i}회 실행되었습니다.");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            for (int i = 1; i <= 10; i += 2)//시작점; 목표와비교; 증감 or 할당 연산자
            {
                Console.WriteLine($"반복문이{i}회 실행되었습니다.");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //홀수일때 출력이 되도록 설계를 해보겠습니다.
            for (int i = 0; i <= 10; i++)
            {
                if (i % 2 == 1)
                {
                    Console.WriteLine(i);
                }
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //브레이크문을 넣으면 적정선에서 탈출한다.
            //조건이 항상 참이면 반복문은 무한히 실행한다
            //break문을 넣으면 해당 구문을 탈출한다.


            for (int i = 0; i <= 100; i++)
            {
                Console.WriteLine(i);
                if (i == 10)
                {
                    break;
                }
            }




            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();




            int ii = 1;
            //while은 참일 때 항상 돌아간다.

            while (ii <= 10)
            {
                Console.WriteLine($"지금 조건은 {ii}입니다.");
                ii++;
            }
            //WHILE을 사용하여 0부터 20까지 숫자를 출력하는 프로그램을 만들어 봅시다.

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            int iii = 0;

            while (iii <= 20)
            {
                Console.WriteLine($"지금 숫자는 {iii}입니다.");
                iii++;
            }
            //do while
            //while문과 유사하지만 조건을 검사하기 전에 먼저 실행됨
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            int jj = 0;
            do
            {
                Console.WriteLine(jj);
                jj++;
            } while (jj < 20);
            //do while을 사용할때는 무조건 한번 실행해야 하는 코드가 있을 때 사용


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            string[] 과일 = { "사과", "바나나", "딸기" };
            foreach (var s in 과일)
            {
                Console.WriteLine(s);
            }
            //숫자배열을 만들고 1부터 10까지 담아주고 foreach를 사용하여 하나씩 출력 해 봅시다.

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            int[] 숫자배열 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            foreach (var s in 숫자배열)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //break를 만나면 해당 구문 탈출
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);

                if (i == 5)
                {
                    break;
                }

            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //continue를 만나면 그 부분만 건너 뜀

            for (int i = 0; i < 10; i++)
            {

                if (i == 5)
                {
                    continue;
                }
                Console.WriteLine(i);
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //구구단 2단 만들기
            for (int i = 2; i < 3; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{ i} X { j} = { i* j}");
                }
            }


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 3; i < 4; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 5; i < 6; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 6; i < 7; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 7; i < 8; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 8; i < 9; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 9; i < 10; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 2; i < 10; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
