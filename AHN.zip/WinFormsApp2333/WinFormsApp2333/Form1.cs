using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;

namespace WinFormsApp2333
{
    public partial class Form1 : Form
    {
        byte[] writedata = new byte[8]; // ECC ����� ���� ���� ����
        byte[] readdata = new byte[34]; // ECC ����� ���� �б� ����
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
                       uint connect = CIFX.DriveConnect();
        
            if (connect != 0)
            {
                label3.Text = "���� ����";
                label3.ForeColor = Color.LimeGreen; 
            }
            else
            {
                label3.Text = "���� �ȵ�"; 
                label3.ForeColor = Color.Red; 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
