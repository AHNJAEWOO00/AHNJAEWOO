﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using CIFX_50RE;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace 양솔안녕
{
    public partial class Form1 : Form
    {
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        private string ReadDataConv = "00000000";
        private string WritedataConv = "00000000";
        int Auto = 0;
        public Form1()
        {
            InitializeComponent();
        }
        
        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label1.Text = "OK";
                label1.ForeColor = Color.Blue;
                timer1.Interval = 300;
                timer1.Start();
                button3_Click(null, null);
            }
            else
            {
                label1.Text = "NG";
                label1.ForeColor = Color.Red;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label1.Text == "OK")
            {
                Readdata = CIFX.xChannelRead();

                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                label5.Text = ReadDataConv;

                WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');
                label3.Text = WritedataConv;


                label7.Text = ReadDataConv[6] == '1' ? "전진" : "후진";

                label8.Text = ReadDataConv[4] == '1' ? "전진" : "후진";

            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x01;
            Writedata[0] &= unchecked((byte)~0x02); // A-
            CIFX.xChannelWrite(Writedata);
            button4.Text = "수동운전";
            button4.BackColor = Color.White;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x02; // A-
            Writedata[0] &= unchecked((byte)~0x01); // A+
            CIFX.xChannelWrite(Writedata);
            button4.Text = "수동운전";
            button4.BackColor = Color.White;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x04; // A-
            Writedata[0] &= unchecked((byte)~0x08); // A+
            CIFX.xChannelWrite(Writedata);
            button4.Text = "수동운전";
            button4.BackColor = Color.White;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Writedata[0] |= 0x08; // B-
            Writedata[0] &= unchecked((byte)~0x04); // B+
            CIFX.xChannelWrite(Writedata);
            button4.Text = "수동운전";
            button4.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer2.Interval = 500;
            timer2.Start();
            Auto = 0;
            button4.Text = "자동 운전 중";
            button4.BackColor = Color.Green;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            // 최신 데이터 읽기
           switch (Auto)
            {
                case 0:
                    if (ReadDataConv[7] == '1')
                    {
                        Writedata[0] = 0x01;
                        CIFX.xChannelWrite(Writedata);
                        Auto++;
                    }
                    break;
                case 1:
                    if (ReadDataConv[6] == '1' && ReadDataConv[5] == '1')
                    {
                        Writedata[0] = 0x04;
                        CIFX.xChannelWrite(Writedata);
                        Auto++;
                    }
                    break;
                case 2:
                    if (ReadDataConv[4] == '1')
                    {
                        Writedata[0] = 0x0a;
                        CIFX.xChannelWrite(Writedata);
                        Auto++;
                    }
                    break;
                case 3:
                    if (ReadDataConv[7] == '1' && ReadDataConv[5] == '1')
                    {
                        Auto = 0;
                    }
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Stop();
            Auto = 0;
            button4.Text = "자동 운전 정지";
            button4.BackColor = Color.Red;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            timer2.Stop();
            Auto = 0;
            Writedata[0] = (byte)0x0a;
            CIFX.xChannelWrite(Writedata);
            button4.Text = "실린더 초기화";
            button4.BackColor = Color.Pink;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
