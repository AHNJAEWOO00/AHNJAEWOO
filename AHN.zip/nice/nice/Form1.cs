﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;

namespace nice
{
    public partial class Form1: Form
    {


        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        string ReaddataConv = "00000000";//ReaddataConv 의 byte값 모두 0
        private string WritedataConv;
        int Auto = 0;



        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();//이더켓 마스터 접속
            if (connect != 0)
            {
                label3.Text = "OKEY";
                label3.ForeColor = Color.Green;
                timer1.Interval = 1000;
                timer1.Start();

            }
            else
            {
                label3.Text = "Not Okey";
                label3.ForeColor = Color.Red;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //입력카드 18번 배열을 불러오자
            Readdata = CIFX.xChannelRead();
            ReaddataConv  = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
            WritedataConv = Convert.ToString(Writedata[0], 2).PadLeft(8, '0');

            label13.Text = ReaddataConv;
            label15.Text = WritedataConv;


            label5.Text  = ReaddataConv[7] == '1' ? "ON" : "OFF";
            label7.Text  = ReaddataConv[6] == '1' ? "ON" : "OFF";
            label9.Text  = ReaddataConv[5] == '1' ? "ON" : "OFF";
            label11.Text = ReaddataConv[4] == '1' ? "ON" : "OFF";

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ReaddataConv[7]== '1')
            {
                Writedata[0] ^= 0x01;
                CIFX.xChannelWrite(Writedata);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ReaddataConv[6]== '1')
            {
                Writedata[0] ^= 0x01;
                CIFX.xChannelWrite(Writedata);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ReaddataConv[5] == '1')
            {
                Writedata[0] ^= 0x02;
                CIFX.xChannelWrite(Writedata);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ReaddataConv[4] == '1')
            {
                Writedata[0] ^= 0x02;
                CIFX.xChannelWrite(Writedata);
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer2.Interval = 200;
            timer2.Start();
            Auto = 0;

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch(Auto)
            {
                case 0:
                    {
                        if (ReaddataConv[7] =='1')//1번 전진
                        {
                            Writedata[0] = 0x01;
                            CIFX.xChannelWrite(Writedata);
                            Auto++;
                        }
                    }
                    break;
                case 1:
                    {
                        if (ReaddataConv[6] == '1')//2전진
                        {
                            Writedata[0] ^= 0x01;
                            CIFX.xChannelWrite(Writedata);
                            Auto++;
                        }
                    }
                    break;
                case 2:
                    {
                        if (ReaddataConv[7] == '1')//1후진
                        {
                            Writedata[0] ^= 0x02;
                            CIFX.xChannelWrite(Writedata);
                            Auto++;
                        }
                    }
                    break;
                case 3:
                    {
                        if (ReaddataConv[4] == '1')//1후진
                        {
                            Writedata[0] ^= 0x02;
                            CIFX.xChannelWrite(Writedata);
                            Auto++;
                        }
                    }
                    break;
                case 4:
                    {
                        if (ReaddataConv[5] == '1')
                        {
                            Auto = 0;
                        }
                        break;
                    }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Auto = 0;
            timer2.Stop();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Writedata[0] = 0x00;
            CIFX.xChannelWrite(Writedata);
        }
    }
}
