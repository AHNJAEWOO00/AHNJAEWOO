﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;

namespace 실린더_이번엔제발
{
    public partial class Form1: Form
    {
        byte[] writedata = new byte[8];
        byte[] readdata = new byte[34];
        string ReadDataConv;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // EtherCAT 마스터 연결
            uint connect = CIFX.DriveConnect();
            if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.LimeGreen;
                //입력값 출력을 위한 타이머 1
                timer1.Interval = 300;//ms 단위
                timer1.Start();//타이머 스타트
            }
            else
            {
                label3.Text = "NG";
                label3.ForeColor = Color.Red;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label3.Text == "OK")
            {

                readdata = CIFX.xChannelRead();
                string ReadDataConv = Convert.ToString(readdata[18], 2).PadLeft(8, '0');
                if (ReadDataConv.Substring(7, 1) == "1")
                { label5.Text = "ON"; }
                if (ReadDataConv.Substring(7, 1) == "0")
                { label5.Text = "OFF"; }
                if (ReadDataConv.Substring(6, 1) == "1")
                { label7.Text = "ON"; }
                if (ReadDataConv.Substring(6, 1) == "0")
                { label7.Text = "OFF"; }
                if (ReadDataConv.Substring(5, 1) == "1")
                { label9.Text = "ON"; }
                if (ReadDataConv.Substring(5, 1) == "0")
                { label9.Text = "OFF"; }
                if (ReadDataConv.Substring(4, 1) == "1")
                { label11.Text = "ON"; }
                if (ReadDataConv.Substring(4, 1) == "0")
                { label11.Text = "OFF"; }
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 7번째 비트가 true일 때 (0000 0001)
            if (ReadDataConv[7] == '1')
            {
                writedata[0] ^= (byte)0x01;
                CIFX.xChannelWrite(writedata);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 6번째 비트가 true일 때 (0000 0010)
            if (ReadDataConv[6] == '1')
            {
                writedata[0] ^= (byte)0x01;
                CIFX.xChannelWrite(writedata);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 5번째 비트가 true일 때 (0000 0100)
            if (ReadDataConv[5] == '1')
            {
                writedata[0] ^= (byte)0x02;
                CIFX.xChannelWrite(writedata);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // 4번째 비트가 true일 때 (0000 1000)
            if (ReadDataConv[4] == '1')
            {
                writedata[0] ^= (byte)0x02;
                CIFX.xChannelWrite(writedata);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {

            writedata[0] = (byte)0x00;
            CIFX.xChannelWrite(writedata);

        }
        private void button5_Click_1(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect(); // connetct변수선언, CIFX함수안에 컨넥트사용
            if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.LimeGreen;
                // 보드가 컨넥션되고, 타이머 구동(설정)
                timer1.Interval = (int)500;// 타이머 ms단위 0.5sec
                timer1.Start();
            }
            else
            {
                label1.Text = "NG";
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            label3.Text = "해제됨";
            label3.ForeColor = Color.Red;
            timer1.Stop();//타이머 정지
            CIFX.close();
        }
    }
}
