﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace 조건문
{
    class Program
    {
        static void Main(string[] args)
        {
            string 조건문 = "안녕하세요.";

            int[] asdf = new int[5] {3,2,1,4,5};

            Array.Sort(asdf);
            for(int i = 0; i < asdf.Length; i++)
            {
                Console.WriteLine(asdf[i]);
            }
            
            
            Array.Reverse(asdf);
            for (int i = 0; i < asdf.Length; i++)
            {
                Console.WriteLine(asdf[i]);
            }
            
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //맞는지 아닌지 알 수 있는 조건만 넣어주면 된다.

            if (조건문.Length > 5)
            {
                Console.WriteLine("조건문은 5자를 넘겼습니다.");
            }
            else if (조건문.Length == 5)
            {
                Console.WriteLine("조건문은 5자입니다.");
            }
            else if (조건문.Length < 5)
            {
                Console.WriteLine("조건문은 5자를 넘기지 않았습니다.");
            }
            else
            {
                Console.WriteLine("조건문은 5자를 넘기지 않았습니다.");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            int 점수 = 85;
            
            if (점수 >= 90)
            {
                Console.WriteLine("A");
            }
            else if (점수 >= 80)
            {
                Console.WriteLine("B");
                int 학점 = 0;
            }
            else if (점수 >= 70)
            {
                Console.WriteLine("C");
            }
            else if (점수 >= 60)
            {
                Console.WriteLine("D");
            }
            else
            {
                Console.WriteLine("F");
            }

            Console.WriteLine();
            Console.WriteLine();

            //스위치 조건문
            string 요일 = "화요일";

            switch (요일)
            {
                case "월요일":
                    Console.WriteLine("오늘은 월요일입니다.");
                    break;
                case "화요일":
                    Console.WriteLine("오늘은 화요일입니다.");
                    break;
                case "수요일":
                    Console.WriteLine("오늘은 수요일입니다.");
                    break;
                case "목요일":
                    Console.WriteLine("오늘은 목요일입니다.");
                    break;
                case "금요일":
                    Console.WriteLine("오늘은 금요일입니다.");
                    break;
                case "토요일":
                    Console.WriteLine("오늘은 토요일입니다.");
                    break;
                default:
                    Console.WriteLine("오늘은 일요일입니다.");
                    break;
            }


            int 숫자 = 11;
            switch (숫자)
            {
                case 1:
                    Console.WriteLine("숫자는 1입니다.");
                    break;
                case 10:
                    Console.WriteLine("숫자는 10입니다.");
                    break;
                case 11:
                    Console.WriteLine("숫자는 11입니다.");
                    break;
                default:
                    Console.WriteLine("숫자는 모릅니다.");
                    break;



            }
                



        }  
    }
}
