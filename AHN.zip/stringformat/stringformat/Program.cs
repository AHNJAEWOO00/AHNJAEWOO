﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringformat
{
    class Program
    {
        static void Main(string[] args)
        {
            string 더하기 = "한국";
            string 문자열 = "폴리텍";
            Console.WriteLine(더하기 + 문자열);



            string 이름 = "안재우";
            int 개수 = 1;
            string 자기소개 = string.Format("{0}는 사과를 {1}개 먹었다.", 이름, 개수);
            Console.WriteLine(자기소개);


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //{한국} {폴리텍} {1} 수업은{C#}이라는 문자열을 변수4개를 선언하고 string.format을 사용하여 문장을 만들라
            string 국가 = "한국";
            string 학교 = "폴리텍";
            string 몇교시 = "1";
            string 수업 = "C#";
            string 최종문장 = string.Format("{0} {1} {2} 교시 수업은 {3}", 국가, 학교, 몇교시, 수업);
            Console.WriteLine(최종문장);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();





            string 포맷 = $"{국가} {학교} {몇교시} 교시 수업은 {수업}";
            Console.WriteLine(포맷 );

            //$를 사용하여 변수 세개를 집어 넣겠습니다.
            //이번 시간은 {C#} 수업진행중 {포맷$}을 배우는 중{완료}
            string 언어 = "C#";
            string 어떤 = "포맷$";
            string 완료 = "완료";

            string 최종 = $"이번 시간은 {언어} 수업진행중 {어떤} 을 배우는 중 {완료}";
            Console.WriteLine(최종);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();




            StringBuilder sb = new StringBuilder();
            sb.Append("안녕하세요");
            sb.Append(".");
            sb.Append("반갑습니다");
            sb.AppendLine("한줄쓰기");
            sb.Append("이어쓰기");



            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine();


            Console.WriteLine(sb.ToString());
            //stringbuilder를 이용하여 문자를 이어붙이도록 합시다
            //한국 폴리텍 아산
            //캠퍼스 수업중

            StringBuilder sb2 = new StringBuilder();
            sb2.Append("한국");
            sb2.Append(" 폴리텍");
            sb2.AppendLine(" 아산");
            sb2.Append("캠퍼스");
            sb2.Append(" 수업중");

            Console.WriteLine(sb2.ToString());



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();


            //string.join
            string[] 단어 = { "한국", "폴리텍", "아산", "캠퍼스" };
            int[] 숫자 = { 1, 2, 3, 4, 5, 6 };
            double[] 소수점 = { 1.23, 4.56, 7.89 };

            string 합치기 = string.Join("끼끼끼", 단어);
            Console.WriteLine(합치기);
            string 합치기2 = string.Join("-", 숫자);
            Console.WriteLine(합치기2);
            string 합치기3 = string.Join(",", 소수점);
            Console.WriteLine(합치기3);

            string[] 아이우에오 = { "지금", "join", "수업", "진행중" };

            string 합치기4 = string.Join("+-*",아이우에오);
            Console.WriteLine(합치기4);





            Console.WriteLine();
            Console.WriteLine(); 
            Console.WriteLine();
            Console.WriteLine();


            Console.WriteLine(string.Concat(아이우에오));

            //숫자 날짜등 특정 형식을 적용할때 사용
            //N2 - 소수점 2자리 표시(반올림), C- 통화기호표시 , P퍼센트 표시

            double 소수점2 = 123.456113535;
            Console.WriteLine(소수점2.GetType());
            Console.WriteLine(소수점2.ToString().GetType());
            Console.WriteLine(소수점2.ToString("N5"));
            Console.WriteLine(소수점2.ToString("C2"));
            Console.WriteLine(소수점2.ToString("P1"));


            Console.OutputEncoding = Encoding.UTF8;


            //int 형변환  = 45

            int 형변환 = 45;
            Console.WriteLine(형변환.ToString());
            Console.WriteLine(형변환.ToString("C"));
            Console.WriteLine(형변환.ToString("P"));






        }
    }
}
