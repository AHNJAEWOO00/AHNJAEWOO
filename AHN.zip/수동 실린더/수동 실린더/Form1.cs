﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;



namespace WindowsFormsApp1
{
    public partial class form1 : Form
    {
        //ECC Module read/write buffer define
        byte[] Writedata = new byte[8];
        byte[] Readdata = new byte[34];
        string ReadDataConv; // 클래스 수준 변수로 선언
        public form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if (label3.Text == "OK")
            {
                // 채널에서 데이터 읽기
                Readdata = CIFX.xChannelRead();
                // 읽은 데이터의 18번째 바이트를 2진수 문자열로 변환하고 8자리로 맞춤
                ReadDataConv = Convert.ToString(Readdata[18], 2).PadLeft(8, '0');
                //0번째 배열 리드(byte) 데이터를 2진수 문자로 변환 및 8자리 수로  맞춤
                //ex) 0번째 배열 값이 0x08 이라고 가정
                // 1. Convert.ToString(readdata[0], 2) -> 2진수 변환 1000
                // 2. PadLeft(8, '0') -> 8자리로 맞추어서 2진수 변환 빈자리는 0으로 채움
               // 0000 1000
            
//위 문자로 변환시 주의 사항
// 0000 1000 -> 문자로 변환 하게 되면 우측에서 좌측으로 7,6,5,4,3,2,1,0
//비트 기준
            // 0번, 1번 비트 -> 실린더 1 편솔 기준 전/후진
            // 2번, 3번 비트 -> 실린더 2 편솔 기준 전/후진
            // 위 기준으로 프로그램 작성함
            //실린더 1번에 0,1번 비트로 ON/OFF 판정
            //ReadDataConv.Substring(7,1) -> 8개의 데이터 0000 1000 중 좌측부터
//7번째 위치한(0,1,2,3,4,5,6,7) 문자에 1개만 가져옴 명령
            //실린더1번 비트로 ON/OFF 판정
if (ReadDataConv[7] == '1')
                { label5.Text = "ON"; }
                else if (ReadDataConv[7] == '0')
                { label5.Text = "OFF"; }
                if (ReadDataConv[6] == '1')
                { label7.Text = "ON"; }
                else if (ReadDataConv[6] == '0')
                { label7.Text = "OFF"; }
                //실린더 2번 비트로 ON/OFF 판정
                if (ReadDataConv[5] == '1')
                { label9.Text = "ON"; }
                else if (ReadDataConv[5] == '0')
                { label9.Text = "OFF"; }
                if (ReadDataConv[4] == '1')
                { label11.Text = "ON"; }
                else if (ReadDataConv[4] == '0')
                { label11.Text = "OFF"; }
            }
        }
        // 실린더 1
        private void button1_Click(object sender, EventArgs e)
        {
            if (ReadDataConv[7] == '1')
            {
                Writedata[0] ^= 0x01; //전진
                CIFX.xChannelWrite(Writedata);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (ReadDataConv[6] == '1')
            {
                Writedata[0] ^= 0x01; //후진
                CIFX.xChannelWrite(Writedata);
            }
        }
        // 실린더 2
        private void button3_Click(object sender, EventArgs e)
        {
            if (ReadDataConv[5] == '1')
            {
                Writedata[0] ^= 0x02; //전진
                CIFX.xChannelWrite(Writedata);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (ReadDataConv[4] == '1')
            {
                Writedata[0] ^= 0x02; //후진
                CIFX.xChannelWrite(Writedata);
            }
        }
        private void button5_Click(object sender, EventArgs e)//초기화
        {
            Writedata[0] = (byte)0x00;
            CIFX.xChannelWrite(Writedata);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect(); // connetct변수선언, CIFX함수안에
          //  컨넥트사용
        if (connect != 0)
            {
                label3.Text = "OK";
                label3.ForeColor = Color.LimeGreen;
                // 보드가 컨넥션되고, 타이머 구동(설정)
                timer1.Interval = (int)500;// 타이머 ms단위 0.5sec
                timer1.Start();
            }
            else
            {

                label1.Text = "NG";
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            label3.Text = "해제됨";
            label3.ForeColor = Color.Red;
            timer1.Stop();//타이머 정지
            CIFX.close();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

        }
    }
}