﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_class
{
    class Program
    {
        static void Main(string[] args)
        {
            Cat cat1 = new Cat();
            cat1.Name = "냥냥이";
            cat1.Sound();
            cat1.Meew();

            Stationery stat1 = new Stationery();
            stat1.stationery = "볼펜";
            stat1.Buy();
            
            Ballpen bp = new Ballpen();
            bp.stationery = "볼펜";
            bp.Buy();
            bp.Write1();

            Num_add num = new Num_add();
            Console.WriteLine(num.Add(1, 3));
            Console.WriteLine(num.Add(1, 7, 4));
            Console.WriteLine(num.Add(1.545, 3.3462));

            Overloading1 numb1 = new Overloading1();
            Console.WriteLine(numb1.Ahn(1, 2));
            Console.WriteLine(numb1.Ahn(1, 2, 3));
            Console.WriteLine(numb1.Ahn(1.5, 2.3));
            Console.WriteLine(numb1.Ahn(1, 2, 3, 4));
            Console.WriteLine(numb1.Ahn("Pilot", " onboard!"));
        }
    }
}