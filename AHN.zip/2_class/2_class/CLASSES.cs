﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _2_class
{
    class Animal
    {
        public string Name;
        public void Sound()
        {
            Console.WriteLine("동물이 소리냅니다.");
        }
    }
    class Cat : Animal
    {
        public void Meew()
        { 
            Console.WriteLine($"{Name}가 야옹합니다.");
        }
    }
    class Stationery
    {
        public string stationery;
        protected string add;
        public void Buy()
        {
            Console.WriteLine($"{stationery}를 삽니다.");
        }
    }
    class Ballpen:Stationery
    {
        public void Write1()
        {
            Console.WriteLine($"{stationery}로 글을 씁니다.");
        }
    }

    class CLASSES
    {
        string aaaa = "hello World";
    }
    class Num_add
    {
        //Overloading 기존에 있던 함수나 매개변수에 변경이 있을 때 사용
        public int Add(int a, int b)
        {
            return a + b;
        }
        public int Add(int a, int b, int c)
        {
            return a + b + c;
        }  
        public double Add(double a, double b)
        {
            return a + b;
        }
       
    }
    class Overloading1
    {
        public int Ahn(int a, int b)
        {
            return a + b;
        }
        public double Ahn(double a, double b)
        {
            return a + b;
        }
        public string Ahn(string a, string b)
        {
            return a + b;
        }
        public int Ahn(int a, int b, int c)
        {
            return a + b + c;
        }
        public int Ahn(int a, int b, int c, int d)
        {
            return a + b + c + d;
        }
    }

}
