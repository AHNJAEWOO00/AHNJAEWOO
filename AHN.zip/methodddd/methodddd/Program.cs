﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace methodddd
{
    class Program
    {
        static void Main(string[] args)
        {
        //반환없고 매개면수 없고
        //반환없고 매개변수 있고
        //반환있고 매개변수 없고
        //반환있고 매개변수 있고

        void ahn1()
            {
                Console.WriteLine("반환없고 매개변수 없고");
            }
            ahn1();
        void ahn2(int a)
            {
                
                Console.WriteLine(a);
        
            }
            ahn2(300);
        int ahn3()
            {
                Console.WriteLine("반환있고 매개변수 없고");
                return 10;
                               
            }
        Console.WriteLine(ahn3());
        

        int ahn4(int a)
            {
                return a;
            }
         Console.WriteLine(ahn4(1351351));
        }
    }
}
