﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLC_PC_제어
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("{0:x}", 15);
        }
    }
}
