﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CIFX_50RE;




namespace WindowsFormsApp1123123
{
    public partial class Form1: Form
    {

        byte[] writedata = new byte[8]; // ECC 모듈을 위한 쓰기 버퍼
        byte[] readdata = new byte[34]; // ECC 모듈을 위한 읽기 버퍼
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            uint connect = CIFX.DriveConnect();
            // 연결이 성공했는지 확인
            if (connect != 0)
            {
                label3.Text = "정상 연결"; // "정상 연결" 메시지 표시
                label3.ForeColor = Color.LimeGreen; // 텍스트 색상을
            }
            else
            {
                label3.Text = "연결 안됨"; // "연결 안됨" 메시지 표시
                label3.ForeColor = Color.Red; // 텍스트 색상을 빨간색으
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = "해제 됨"; // "해제 됨" 메시지 표시
            label3.ForeColor = Color.Red; // 텍스트 색상을 빨간색으로
            CIFX.close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            writedata[0] = 0x01;
            CIFX.xChannelWrite(writedata); // ECC 모듈에 데이터 쓰기
            label4.Text = "Lamp가 점등되었습니다 ";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            writedata[0] = 0x00;
            CIFX.xChannelWrite(writedata); // ECC 모듈에 데이터 쓰기
            label4.Text = "Lamp가 소등되었습니다 ";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
