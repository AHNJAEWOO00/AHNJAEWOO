﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_MATHOD
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.반환없음,매개변수 없음
            void nothing()
            {
                //단순 화면에 출력만 될뿐 우리에게 값을 주는것이 아님
                Console.WriteLine("아무것도 없는 함수");
            }
            //함수 호출
            nothing();
            
            
            
            //2 반환 없음, 매개변수 있는 함수
            void hello(string input)
            {
                Console.WriteLine($"값:{input}");
            }
            
            hello("입력");
            



            //3 반환있음, 매개변수 없음
            int Add()
            {
                return 1+2;
            }
            Console.WriteLine(Add());//3
            int a = Add();





            //4. 반환 있음 매개변수 있음
            int Sub(int x, int y)
            {
                return x - y;
            }
            Console.WriteLine(Sub(1, 2));






            //1.반환 없고 매개변수 없는 함수 만들기
            //2.반환 없고 매개변수 있는 함수 만들기
            //3.반환 있고 매개변수 없는 함수 만들기
            //4.반환 있고 매개변서 있는 함수 만들기
            
            void Ahn1 ()
            {
                Console.WriteLine("AHN");
            }
            
            Ahn1();

            void Ahn2(int input)
            {
             Console.WriteLine($"Hello {input}");    
            }
            
            Ahn2(123);

            int Ahn3()
            {
                return 50 + 100;
            }
            Console.WriteLine(Ahn3());

            int Ahn4(int a1, int b)
            {
                return a1 * b;
            }
            Console.WriteLine(Ahn4(5, 5));
        }
    }
}
