﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrey_복습
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] 소수점배열 = new double[5];
            소수점배열[0] = 1.25;
            소수점배열[1] = -11.25;
            소수점배열[2] = 251.3325;
            소수점배열[3] = 51.15225;
            소수점배열[4] = -3871.113525;

            Console.WriteLine(소수점배열);
            Console.WriteLine(소수점배열[0]);
            Console.WriteLine(소수점배열[1]);
            Console.WriteLine(소수점배열[2]);
            Console.WriteLine(소수점배열[3]);
            Console.WriteLine(소수점배열[4]);

            bool[] 참거짓배열 = new bool[10];
            참거짓배열[0] = true;

            //2차원 배열 선언
            int[,] 숫자배열 = new int[3, 3] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int 값가져오기 = 숫자배열[2, 1];
            Console.WriteLine(값가져오기);

            //가변배열
            int[][] 가변배열 = new int[3][];
            가변배열[0] = new int[] { 1, 2 };
            가변배열[1] = new int[] { 3, 4,6,1,6,13 };
            가변배열[2] = new int[] { 1135, 13542,135,62346,342 };

            int 숫자1 = 가변배열 [2][3];
            Console.WriteLine(숫자1);



            // 형변환
            //암시적 형변환
            short 진짜작음 = 1;
            long 진짜큼 = 진짜작음;
            Console.WriteLine(진짜큼);

            int 정수 = 123;
            double 실수 = 정수;

            Console.WriteLine(정수);
            Console.WriteLine(실수);

            double 소수점 = 1.45;
            int 양수 = (int)소수점;
            Console.WriteLine(양수);



            Console.WriteLine();
            Console.WriteLine();



            //명시적 형변환
            string 인치 = "1.7";
            double 인치변환 = Convert.ToDouble(인치);
            Console.WriteLine(인치);
            Console.WriteLine(인치변환);
            Console.WriteLine(인치+1);
            Console.WriteLine(인치변환+1);

            //파스와 트라이파스

            string 파스 = "3.14";
            double 형변환 = double.Parse(파스);

            Console.WriteLine(파스);

            string 참거짓 = "5.5";
            bool 소수점확인 = float.TryParse(참거짓, out float 결과값);
            if (소수점확인)
            {
                Console.WriteLine("결과값은 :" + 결과값);
            }
            else
            {
                Console.WriteLine("확인실패");
            }








        }
    }
}
