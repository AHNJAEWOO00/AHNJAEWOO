﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Bokseup
{
    class Program
    {
        static void Main(string[] args)
        {
            //정수형 선언
            byte age = 25;
            Console.WriteLine("나이" + age);
            short temp = 16;
            Console.WriteLine("온도" + temp);
            int number = 100;
            Console.WriteLine("숫자" + number);
            long dis = 1234567;
            Console.WriteLine("거리" + dis);
            uint pos = 235235;
            Console.WriteLine("양수" + pos);
            ulong bignumber = 2937590287335;
            Console.WriteLine("큰 숫자" + bignumber);

            //실수형 선언
            float pi = 3.14f;
            Console.WriteLine("원주율" + pi);
            double circle = 2.5;
            Console.WriteLine("원의 반지름" + circle);
            decimal moniter = 1.75m;
            Console.WriteLine("모니터 크기" + moniter);

            //논리형 자료형 예제
            //불리언 참과 거짓을 표현하는 자료형

            bool avocado = true;

            if (avocado)
            {
                Console.WriteLine("우유 6개 사오기");
            }
            else
            {
                Console.WriteLine("빈손으로 오기");
            }
            bool rain = false;
            if(rain)
            {
                Console.WriteLine("비가온다");
            }
            else
            {
                Console.WriteLine("비가 오지 않는다");
            }
            //문자형 자료형 예제
            bool insum = char.IsDigit('a');
            Console.WriteLine(insum);

            //문자를 합칠 수 있는 기능
            string hello = "안녕하세요";
            string plus = "문자를 더할 수 있음";
            string total = hello + plus;



            // 문자열의 길이를 확인할 수 있는 기능
            //반환형 정수 int
            int strlen = total.Length;
            Console.WriteLine(strlen);
            //string 문자열의 기능
            //문자열 자르기 1. 지정 숫자부터 끝까지  2. 지정 숫자부터 지정 길이까지.
            string substr = total.Substring(2);
            Console.WriteLine(substr);
            Console.WriteLine(substr.Substring(2,5));

            // object 자료형들의 자료형
            object par = 123;
            object str = "문자열";
            Console.WriteLine(par);
            Console.WriteLine(str);



        }
    }
}
